<?php

$table = 'event_checks';
$api['checks'] = array();

//создание
if($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (access('user active')) {
		$fields = array(
			//'user'=>'required int',
			'checkpoint' => 'int',
			'lat' => 'required text',
			'lng' => 'required text',
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		//dd($post);
		//сообщения с ошибкой заполнения
		$message = form_validate($fields, $post);
		//log_add('login.txt',$post,true);
		if (count($message) == 0 AND $api['error'] == 0) {
			//если чекпоин указана
			if ($post['checkpoint']) {
				$checkpoint = mysql_select("SELECT * FROM event_checkpoints WHERE id=" . $post['checkpoint'], 'row');
				if ($checkpoint) {
					$event = mysql_select("
						SELECT * FROM events
						WHERE id=" . $checkpoint['event'] . " AND date='" . $config['date'] . "' AND display=1
					", 'row');
					if ($event) {
						//зарегистрирован ли на мероприятие
						$event_user = mysql_select("
							SELECT * FROM `event_users`
							WHERE event=".$event['id']." AND user=" . $user['id']
						, 'row');
						if ($event_user) {
							//проверка координат
							$api['distance'] = get_distanse($checkpoint['lat'], $checkpoint['lng'], $post['lat'], $post['lng']);
							if ($api['distance'] < 1000) {
								$check = mysql_select("
									SELECT * FROM event_checks
									WHERE checkpoint=" . $checkpoint['id'] . " AND user=" . $user['id'], 'row');
								if ($check) {

								}
								else {
									$check = $post;
									$check['event'] = $event['id'];
									$check['created'] = $config['datetime'];
									$check['updated'] = $config['datetime'];
									$check['user'] = $user['id'];
									$check['id'] = mysql_fn('insert', $table, $check);
								}
								$api['checks'][] = $check;
							}
							else {
								$api['error'] = 331;
							}
						}
						else $api['error'] = 333;
					}
					else {
						$api['error'] = 332;
					}
				}
				else {
					$api['error'] = 321;
				}
			}
			else {
				//если нет то ищем ближайший
				$checkpoints = mysql_select("
					SELECT ec.* 
					FROM event_checkpoints ec, events e, event_users eu
					WHERE ec.event=e.id AND eu.event=e.id AND eu.user=".$user['id']."
						AND e.date='" . $config['date'] . "' AND e.display=1
				", 'rows');
				if ($checkpoints) {
					//$api['_checkpoints'] = $checkpoints;
					foreach ($checkpoints as $checkpoint) {
						$api['distance'] = get_distanse($checkpoint['lat'], $checkpoint['lng'], $post['lat'], $post['lng']);
						if ($api['distance'] < 1000) {
							$check = mysql_select("
								SELECT * FROM event_checks
								WHERE checkpoint=" . $checkpoint['id'] . " AND user=" . $user['id'], 'row');
							if ($check) {
								$check = to_int($check);
							}
							else {
								$check = to_int($post);
								$check['checkpoint'] = (int)$checkpoint['id'];
								$check['event'] = (int)$checkpoint['event'];
								$check['created'] = $config['datetime'];
								$check['updated'] = $config['datetime'];
								$check['user'] = $user['id'];
								$check['id'] = mysql_fn('insert', $table, $check);
							}
							$api['checks'][] = to_int($check);
						}
					}
					if ($api['checks']==false) {
						$api['error'] = 331;
					}
				}
				else {
					$api['error'] = 334;
				}
			}
		}
		else {
			if ($api['error'] == 0) $api['error'] = 1;
		}
	}
	else $api['error'] = 12;
}
