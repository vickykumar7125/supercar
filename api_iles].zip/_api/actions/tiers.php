<?php

$table = 'user_tiers';

//список
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	$fields = array(
		'limit' => 'int',
		'n' => 'int',
	);
	//создание массива $post
	$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
	$where = '';
	if ($post['limit'] < 1) $post['limit'] = 20;
	if ($post['n'] < 1) $post['n'] = 1;
	//$api['request'] = $_REQUEST;
	$api['models'] = mysql_data(
		"SELECT * FROM ".$table." WHERE 1 $where ORDER BY rank DESC",
		"SELECT count(id) FROM ".$table." WHERE 1 $where",
		$post['limit'],
		$post['n']
	);
	foreach ($api['tires']['list'] as $k => $v) {
		$api['tires']['list'][$k] = to_int($v);
		//$api['tires']['list'][$k]['img'] = $v['img'] ? $config['http_domain'] . get_img($table, $v) : '';
	}
}

//создание/редактирование
if($_SERVER['REQUEST_METHOD'] == 'POST' OR $_SERVER['REQUEST_METHOD'] == 'PUT') {
	$fields = array(
		'name'=>'required text',
		'rank'=>'int',
		'display'=>'boolean',
	);
	//создание массива $post
	$post = form_smart($fields,stripslashes_smart($_REQUEST)); //print_r($post);
	if ($_SERVER['REQUEST_METHOD'] == 'PUT' AND empty($_REQUEST['rank'])) unset($post['rank']);
	if (empty($_REQUEST['display'])) $post['display'] = 1;

	if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
		$post['id'] = $id;
		if ($id<1) $api['error'] = 131;
	}
	//dd($post);
	//сообщения с ошибкой заполнения
	$message = form_validate($fields,$post);
	//log_add('login.txt',$post,true);
	if (count($message)==0 AND $api['error']==0) {
		if (isset($post['id'])) {
			if ($tire = mysql_select("SELECT * FROM ".$table." WHERE id=".$post['id'],'row')) {
				if (empty($post['rank'])) $post['rank'] = $tire['rank'];
				mysql_fn('update',$table,$post);
			}
			else  $api['error'] = 131;
		}
		else {
			$post['created'] = $config['datetime'];
			if ($post['id'] = mysql_fn('insert', $table, $post)) {
			}
			else {
				$api['error'] = 31;
			}
		}
		if ($api['error']==0) {
			$api['tire'] = to_int($post);
		}

	}
	else {
		if ($api['error']==0) $api['error'] = 1;
	}
}

if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
	$post['id'] = $id;
	//сообщения с ошибкой заполнения
	if ($post['id'] AND $tier = mysql_select("SELECT * FROM ".$table." WHERE id=".$post['id'],'row')) {
		$usr = mysql_select("SELECT id FROM users WHERE tier=" . $post['id'] . " LIMIT 1", 'string');
		if ($usr==0) {
			mysql_fn('delete', $table, $post);
		}
		else $api['error'] = 132;
	}
	else  $api['error'] = 131;

}