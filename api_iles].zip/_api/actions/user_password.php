<?php


$fields = array(
	'password'	=> 'required text',
);

//создание массива $post
$post = form_smart($fields,stripslashes_smart($_REQUEST)); //print_r($post);

//сообщения с ошибкой заполнения
$message = form_validate($fields,$post);

//log_add('login.txt',$post,true);
if (access('user active')) {
	if (count($message) == 0) {
		//соль
		$post['salt'] = md5(time());
		//новый хеш
		$post['hash']   = user_hash_db($post['salt'],$post['password']);
		$post['token'] = md5(time().$q['hash']);
		unset($post['password']);
		$post['id'] = $user['id'];
		mysql_fn('update', 'users', $post);
		$api['token'] = $post['token'];
	}
	else $api['error'] = 1;
}
else $api['error'] = 12;