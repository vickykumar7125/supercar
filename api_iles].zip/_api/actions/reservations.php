<?php

$table = 'event_users';

//список
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	if (access('user moder')) {
		$fields = array(
			'limit' => 'int',
			'n' => 'int',
			'event' => 'int'
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		$where = '';
		if ($post['limit'] < 1) $post['limit'] = 20;
		if ($post['n'] < 1) $post['n'] = 1;
		if ($post['event']) $where = " AND event='" . $post['event'] . "'";
		//$api['request'] = $_REQUEST;
		$api['reservations'] = mysql_data(
			"SELECT * FROM " . $table . " WHERE 1 $where ORDER BY created DESC",
			"SELECT count(id) FROM " . $table . " WHERE 1 $where",
			$post['limit'],
			$post['n']
		);
		foreach ($api['reservations']['list'] as $k => $v) {
			$api['reservations']['list'][$k] = to_int($v);
		}
	}
	else $api['error'] = 12;
}

//создание
if($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (access('user active')) {
		$fields = array(
			//'user'=>'required int',
			'car' => 'required int',
			'guests' => 'int',
			'event' => 'required int',
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		//dd($post);
		//сообщения с ошибкой заполнения
		$message = form_validate($fields, $post);
		//log_add('login.txt',$post,true);
		if (count($message) == 0 AND $api['error'] == 0) {
					$car = mysql_select("SELECT * FROM cars WHERE user=" . $user['id'] . " AND id=" . $post['car'], 'row');
			if ($car) {
				$event = mysql_select("SELECT * FROM events WHERE id=" . $post['event'], 'row');
				if ($event) {
					if (access('events user_add', $event)) {
						$old = mysql_select("
							SELECT id 
							FROM ".$table."
							WHERE user=".$user['id']." AND event=".$post['event'],
							'string');
						if ($old==0) {
							$limit = mysql_select("SELECT SUM(1) cars, SUM(guests) quests FROM " . $table . " WHERE event=" . $post['event'], 'row');
							//$api['query'] = "SELECT SUM(1) cars, SUM(guests) quests FROM " . $table . " WHERE event=" . $post['event'];
							//$api['limit'] = $limit;
							if (($limit['cars'] < $event['limit_cars'] OR $event['limit_cars']==0)
								AND ($limit['guests'] <= $event['limit_guests'] + $post['guests'] OR $event['limit_guests']==0)
							) {
								$post['created'] = $config['datetime'];
								$post['user'] = $user['id'];
								if ($post['id'] = mysql_fn('insert', $table, $post)) {
									//$post['checks'] = 0;
									$api['reservation'] = to_int($post);
								}
								else {
									$api['error'] = 31;
								}
							}
							else $api['error'] = 313;
						}
						else {
							$api['error'] = 314;
						}
					}
					else $api['error'] = 312;
				}
				else {
					$api['error'] = 301;
				}
			}
			else {
				$api['error'] = 311;
			}
		}
		else {
			if ($api['error'] == 0) $api['error'] = 1;
		}
	}
	else $api['error'] = 12;
}


if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
	$fields = array(
		'event' => 'required int',
		'user' => 'required int',
	);
	$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
	//сообщения с ошибкой заполнения
	$message = form_validate($fields, $post);
	//log_add('login.txt',$post,true);
	if (count($message) == 0) {
		if ($event_users = mysql_select("SELECT * FROM " . $table . " WHERE user=" . $post['user'] . " AND event=" . $post['event'], 'row')) {
			if (access('event_users delete', $event_users)) {
				mysql_fn('delete', $table, $event_users);
				mysql_fn('delete', 'event_checks', '', " AND event=" . $event_users['event'] . " AND user=" . $event_users['user']);
			}
			else  $api['error'] = 12;
		}
		else  $api['error'] = 12;
	}
	else $api['error'] = 1;
}
