<?php

$table = 'past_events';

//список
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	//if (access('user active')) {
		$fields = array(
			'limit' => 'int',
			'n' => 'int',
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		if ($post['limit'] < 1) $post['limit'] = 20;
		if ($post['n'] < 1) $post['n'] = 1;

		$where = '';

		if (access('user moder') == false) {
			$where .= ' AND display=1';
		}
		//$api['where'] = $where;

		//$api['request'] = $_REQUEST;
		$api['past_events'] = mysql_data(
			"SELECT * FROM " . $table . " WHERE 1 $where ORDER BY date",
			"SELECT count(id) FROM " . $table . " WHERE 1 $where",
			$post['limit'],
			$post['n']
		);
		foreach ($api['past_events']['list'] as $k => $v) {
			$api['past_events']['list'][$k] = to_int($v);
			$imgs = get_imgs($table,$v);
			$api['past_events']['list'][$k]['imgs'] = array();
			foreach ($imgs as $k1=>$v1) {
				$api['past_events']['list'][$k]['imgs'][] = array(
					'n' => $k1,
					'img' => $config['http_domain'].$v1['_']
				);
			}
		}
	//} else $api['error'] = 12;
}

//создание/редактирование
if($_SERVER['REQUEST_METHOD'] == 'POST' OR $_SERVER['REQUEST_METHOD'] == 'PUT') {
	if (access('user moder')) {
		$fields = array(
			'name' => 'required text',
			'text' => 'required text',
			'date' => 'required text',
			'participants' => 'required int',
			'location' => 'required text',
			'display' => 'boolean',

		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		if (empty($_REQUEST['display'])) $post['display'] = 1;

		$fields_img = array(
			'imgs_add' => 'array_string',
			'imgs_del' => 'string_int',
		);
		$images = form_smart($fields_img, stripslashes_smart($_REQUEST)); //print_r($post);

		if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
			$post['id'] = $id;
			if ($id < 1) $api['error'] = 351;
		}
		//dd($post);
		//сообщения с ошибкой заполнения
		$message = form_validate($fields, $post);
		$api['message'] = $message;
		//log_add('login.txt',$post,true);
		if (count($message) == 0 AND $api['error'] == 0) {
			if (isset($post['id'])) {
				if ($past_event = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {
					mysql_fn('update', $table, $post);
					$post['imgs'] = $past_event['imgs'];
				} else  $api['error'] = 351;
			}
			else {
				$post['created'] = $config['datetime'];
				if ($post['id'] = mysql_fn('insert', $table, $post)) {
					$post['imgs'] = '';
				}
				else {
					$api['error'] = 31;
				}
			}
			if ($api['error'] == 0) {
				//загрузка/удаление картинок
				$post = api_imgs($table, $post, 'imgs', $images);
				$api['past_event'] = to_int($post);
				$api['past_event']['imgs'] = array();
				if ($post['imgs']) {
					$imgs = get_imgs ($table, $post);
					foreach ($imgs as $k=>$v) {
						$api['past_event']['imgs'][] = array(
							'n'=>$k,
							'img'=>$config['http_domain'] . $v['_']
						);
					}
				}
			}

		} else {
			if ($api['error'] == 0) $api['error'] = 1;
		}
	}
	else $api['error'] = 12;
}

if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
	if (access('user moder')) {
		$post['id'] = $id;
		//сообщения с ошибкой заполнения
		if ($post['id'] AND $past_event = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {
			mysql_fn('delete', $table, $post);
			$relative = 'files/' . $table . '/' . $post['id'] . '/';
			$path = ROOT_DIR . $relative;
			if (is_dir($path)) {
				delete_all($path);
				if (is_dir($path)) {

				}
			}
			if (!is_dir($path)) {
				//v1.3.17 - удаление превью
				if (isset($config['_imgs'][$table])) {
					foreach ($config['_imgs'][$table] as $k => $v) {
						$path = ROOT_DIR . '_imgs/' . $v . '/' . $relative;
						delete_all($path);
					}
				}
			}

		}
		else  $api['error'] = 351;
	}
	else  $api['error'] = 12;
}