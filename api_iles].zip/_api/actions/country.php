<?php

$table = 'country';

//список
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	$fields = array(
		'limit' => 'int',
		'n' => 'int',
	);
	//создание массива $post
	$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
	if ($post['limit'] < 1) $post['limit'] = 20;
	if ($post['n'] < 1) $post['n'] = 1;

	$where = '';
	if (access('user moder')==false) {
		$where.= ' AND display=1';
	}

	//$api['request'] = $_REQUEST;
	$api['country'] = mysql_data(
		"SELECT * FROM ".$table." WHERE 1",
		"SELECT count(id) FROM ".$table." WHERE 1",
		$post['limit'],
		$post['n']
	);
//	foreach ($api['country']['list'] as $k => $v) {
////		$api['country']['list'][$k] = to_int($v);
//		//$api['tires']['list'][$k]['img'] = $v['img'] ? $config['http_domain'] . get_img($table, $v) : '';
//	}
}