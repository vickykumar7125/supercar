<?php

$table = 'partners';

//список
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	if (access('user moder')) {
		$fields = array(
			'limit' => 'int',
			'n' => 'int',
			'type' => 'int'
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		if ($post['limit'] < 1) $post['limit'] = 20;
		if ($post['n'] < 1) $post['n'] = 1;

		$where = '';
		//if ($post['type'] == 1) $where .= " AND date>='" . $config['date'] . "'";
		//if ($post['type'] == 2) $where .= " AND date<'" . $config['date'] . "'";

		//$api['request'] = $_REQUEST;
		$api['partners'] = mysql_data(
			"SELECT * FROM " . $table . " WHERE 1 $where ORDER BY name",
			"SELECT count(id) FROM " . $table . " WHERE 1 $where",
			$post['limit'],
			$post['n']
		);
		foreach ($api['partners']['list'] as $k => $v) {
			$api['partners']['list'][$k] = to_int($v);
			$api['partners']['list'][$k]['img'] = $v['img'] ? $config['http_domain'] . get_img($table, $v) : '';
		}
	}
	else $api['error'] = 12;
}

//создание/редактирование
if($_SERVER['REQUEST_METHOD'] == 'POST' OR $_SERVER['REQUEST_METHOD'] == 'PUT') {
	if (access('user moder')) {
		$fields = array(
			'name' => 'required text',
			'phone' => 'required text',
			'location' => 'required text',
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);

		$fields_img = array(
			'img_add' => 'text',
			'img_del' => 'int'
		);
		$images = form_smart($fields_img, stripslashes_smart($_REQUEST)); //print_r($post);

		if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
			$post['id'] = $id;
			if ($id < 1) $api['error'] = 401;
		}
		//сообщения с ошибкой заполнения
		$message = form_validate($fields, $post);
		if (count($message) == 0 AND $api['error'] == 0) {
			if (isset($post['id'])) {
				if ($partner = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {
					mysql_fn('update', $table, $post);
					$post['img'] = $partner['img'];
				} else  $api['error'] = 401;
			}
			else {
				$post['created'] = $config['datetime'];
				if ($post['id'] = mysql_fn('insert', $table, $post)) {
					$post['img'] = '';
				}
				else {
					$api['error'] = 31;
				}
			}
			if ($api['error'] == 0) {
				//загрузка/удаление картинок
				$post = api_img($table, $post, 'img', $images);
				$api['partner'] = to_int($post);
				if ($post['img']) {
					$api['partner']['img'] = $config['http_domain'] . get_img($table, $post);
				}
			}

		} else {
			if ($api['error'] == 0) $api['error'] = 1;
		}
	}
	else $api['error'] = 12;
}

if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
	if (access('user moder')) {
		$post['id'] = $id;
		//сообщения с ошибкой заполнения
		if ($post['id'] AND $partner = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {

			//$reservation = mysql_select("SELECT id FROM event_users WHERE event=" . $post['id'], 'string');
			//if ($reservation == 0) {
				mysql_fn('delete', $table, $post);
				$relative = 'files/' . $table . '/' . $post['id'] . '/';
				$path = ROOT_DIR . $relative;
				if (is_dir($path)) {
					delete_all($path);
					if (is_dir($path)) {

					}
				}
				if (!is_dir($path)) {
					//v1.3.17 - удаление превью
					if (isset($config['_imgs'][$table])) {
						foreach ($config['_imgs'][$table] as $k => $v) {
							$path = ROOT_DIR . '_imgs/' . $v . '/' . $relative;
							delete_all($path);
						}
					}
				}
			//}
			//else $api['error'] = 302;
		}
		else  $api['error'] = 401;
	}
	else  $api['error'] = 12;
}