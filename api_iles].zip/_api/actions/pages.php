<?php

$table = 'pages';

//список
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	//if (access('user active')) {
		$fields = array(
			'limit' => 'int',
			'n' => 'int',
			'url'=>'string'
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		if ($post['limit'] < 1) $post['limit'] = 20;
		if ($post['n'] < 1) $post['n'] = 1;

		$where = '';

		if ($post['url']) {
			$where .= " AND url = '".mysql_res($post['url'])."'";
		}
		//$api['where'] = $where;

		//$api['request'] = $_REQUEST;
		$api['pages'] = mysql_data(
			"SELECT * FROM " . $table . " WHERE 1 $where ORDER BY id",
			"SELECT count(id) FROM " . $table . " WHERE 1 $where",
			$post['limit'],
			$post['n']
		);

		foreach ($api['pages']['list'] as $k => $v) {
			$api['pages']['list'][$k] = to_int($v);
		}

	//} else $api['error'] = 12;
}
