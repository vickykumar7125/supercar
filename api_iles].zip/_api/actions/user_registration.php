<?php

//$api['token'] = '';

//user auth

$fields = array(
	'email'	=> 'required text',
	'phone'=> 'text',
	'name'=> 'required text',
	//'hash'	=> 'required text',
	'uid'   => 'text',
);

$fields_car = array(
	'brand'	=> 'int',
	'model'=> 'int',
);

//создание массива $post
$post = form_smart($fields,stripslashes_smart($_REQUEST)); //print_r($post);

$car = form_smart($fields_car,stripslashes_smart($_REQUEST)); //print_r($car);

//$post['password2'] = $post['password'];

//сообщения с ошибкой заполнения
$message = form_validate($fields,$post);
$message2 = form_validate($fields_car,$car);

//log_add('login.txt',$post,true);


if (count($message) == 0 AND count($message2) == 0) {
	if (filter_var($post['email'],FILTER_VALIDATE_EMAIL)) {
		$post['token'] = md5(time() . $post['email']);

		//удаление пользователя с таким же емейлом в статусе незавершен
		$incomplete = mysql_select("SELECT id FROM users WHERE status=9 AND email = '" . mysql_res(strtolower($post['email'])) . "'  LIMIT 1", 'string');
		if ($incomplete) {
			mysql_fn('delete','users',$incomplete);
			delete_imgs('users',$incomplete);
			$cars = mysql_select("SELECT * FROM cars WHERE user=".$incomplete, 'rows');
			foreach ($cars as $car) {
				mysql_fn('delete', 'cars', $car['id']);
				delete_imgs('cars',$car['id']);
			}
		}

		//проверка существования мыла
		$num_rows = mysql_select("SELECT id FROM users WHERE email = '" . mysql_res(strtolower($post['email'])) . "'  LIMIT 1", 'num_rows');
		if ($num_rows == 1) {
			$api['error'] = 111;
		}
		//проверка существования телефона
		/*
		if ($post['phone']) {
			$num_rows = mysql_select("SELECT id FROM users WHERE phone = '" . mysql_res(strtolower($post['phone'])) . "'  LIMIT 1", 'num_rows');
			if ($num_rows == 1)
				$api['error'] = 114;
		}
		*/

		//регистарация
		if ($api['error'] == 0) {
			//v1.3.3 - разрешить null
			$config['mysql_null'] = true;
			if ($post['phone'] == '') $post['phone'] = null;
			$post['last_visit'] = $config['datetime'];
			$post['created'] = $config['datetime'];
			$post['salt'] = md5(time());
			$post['hash'] = user_hash_db($post['salt'], $post['password']);
			//$post['type'] = 0;
			$post['status'] = 9;
			//по умолчанию ставим запомнить меня
			$post['remember_me'] = 1;

			if ($post['id'] = mysql_fn('insert', 'users', $post)) {
				$post['id2'] = $post['id'];
				mysql_fn('update','users',$post);
				$car['user'] = $post['id'];
				if ($car['brand']) {
					$car['id'] = mysql_fn('insert', 'cars', $car);
					$api['car'] = to_int($car);
				}
				else {
					$api['car'] = array();
				}

				$api['user'] = array(
					'id' => $post['id'],
					'email' => $post['email'],
					'phone' => $post['phone'],
					'name' => $post['name'],
					'status' => $post['status'],
					'tiers' => ''
				);
				$api['user'] = to_int($api['user']);
				$api['token'] = $post['token'];
				pusher('user_registration',1,$post);
				//require_once(ROOT_DIR . 'functions/mail_func.php');
				//mailer('registration', $lang['id'], $post, $post['email']);
			}
			else {
				$api['error'] = 31;
			}
		}
	}
	else $api['error'] = 112;
}
else {
	$api['error'] = 1;
}
