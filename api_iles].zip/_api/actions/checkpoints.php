<?php

$table = 'event_checkpoints';

//список
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	if (access('user active')) {
		$fields = array(
			'limit' => 'int',
			'n' => 'int',
			'event' => 'int'
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		if ($post['limit'] < 1) $post['limit'] = 20;
		if ($post['n'] < 1) $post['n'] = 1;

		$where = '';
		if ($post['event']) $where .= " AND ec.event=" . $post['event'] . "";

		//$api['where'] = $where;
		//$api['request'] = $_REQUEST;
		$api['checkpoints'] = mysql_data(
			"
				SELECT ec.*,r.id checked
				FROM event_checkpoints ec
				LEFT JOIN event_checks r ON r.checkpoint=ec.id AND r.user=".$user['id']." 
				WHERE 1 $where
				ORDER BY ec.hours, ec.minutes
			",
			"SELECT count(ec.id) FROM " . $table . " ec WHERE 1 $where",
			$post['limit'],
			$post['n']
		);
		foreach ($api['checkpoints']['list'] as $k=>$v) {
			$api['checkpoints']['list'][$k] = to_int($v);
			$api['checkpoints']['list'][$k]['checked'] = intval($v['checked']);
			//$api['checkpoints']['list'][$k]['checked'] = intval($v['checked']);
		}
	}
	else $api['error'] = 12;
}

//создание/редактирование
if($_SERVER['REQUEST_METHOD'] == 'POST' OR $_SERVER['REQUEST_METHOD'] == 'PUT') {
	if (access('user moder')) {
		$fields = array(
			'name' => 'required text',
			'lat' => 'required text',
			'lng' => 'required text',
			'hours' => 'int',
			'minutes' => 'int',
		);
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$fields['event'] = 'required int';
		}
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);

		if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
			$post['id'] = $id;
			if ($id < 1) $api['error'] = 321;
		}
		//dd($post);
		//сообщения с ошибкой заполнения
		$message = form_validate($fields, $post);
		//log_add('login.txt',$post,true);
		if (count($message) == 0 AND $api['error'] == 0) {
			if (isset($post['id'])) {
				if ($event = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {
					mysql_fn('update', $table, $post);
					$post['img'] = $event['img'];
				}
				else  $api['error'] = 321;
			}
			else {
				$post['created'] = $config['datetime'];
				if ($post['id'] = mysql_fn('insert', $table, $post)) {

				}
				else {
					$api['error'] = 31;
				}
			}
			if ($api['error'] == 0) {
				$api['checkpoint'] = to_int($post);
			}

		} else {
			if ($api['error'] == 0) $api['error'] = 1;
		}
	}
	else $api['error'] = 12;
}

if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
	if (access('user moder')) {
		$post['id'] = $id;
		//сообщения с ошибкой заполнения
		if ($post['id'] AND $event = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {
			//todo - проверка есть ли записи по чекпоинтам
			$reservation = mysql_select("SELECT id FROM event_users WHERE event=" . $post['id'], 'string');
			if ($reservation == 0) {
				mysql_fn('delete', $table, $post);
			}
			else $api['error'] = 322;
		}
		else  $api['error'] = 321;
	}
	else  $api['error'] = 12;
}