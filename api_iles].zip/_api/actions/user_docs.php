<?php

$table = 'users';


//редактирование
if($_SERVER['REQUEST_METHOD'] == 'PUT') {
	//если не админ то только себя можно редактировать
	if (access('user moder')==false) {
		if (access('user active_review') AND $user['id']!=$id) {
			$api['error'] = 12;
		}
	}

	if ($api['error']==0 AND access('user active_review')) {

		//создание массива $post
		$fields_img = array(
			'licenses_add' => 'array_string',
			'licenses_del' => 'string_int',
			'docs_add' => 'array_string',
			'docs_del' => 'string_int'
		);
		$images = form_smart($fields_img, stripslashes_smart($_REQUEST)); //print_r($post);
		$api['images'] = $images;

		$post = array();
		$post['id'] = $id;
		if ($id < 1) $api['error'] = 121;

		if ($api['error'] == 0) {
			if ($post = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {

			}
			else  $api['error'] = 121;

			if ($api['error'] == 0) {
				//загрузка/удаление картинок
				$post = api_imgs($table, $post, 'docs', $images);
				$post = api_imgs($table, $post, 'licenses', $images);
				$api['user'] = $post;
				if ($post['img']) {
					$api['user']['img'] = $config['http_domain'] . get_img($table, $post);
				}
				$api['user']['docs'] = array();
				if ($post['docs']) {
					$imgs = get_imgs ($table, $post,'docs');
					foreach ($imgs as $k=>$v) {
						$api['user']['docs'][] = array(
							'n'=>$k,
							'img'=>$config['http_domain'] . $v['_']
						);
					}
				}
				$api['user']['licenses'] = array();
				if ($post['licenses']) {
					$imgs = get_imgs ($table, $post,'licenses');
					foreach ($imgs as $k=>$v) {
						$api['user']['licenses'][] = array(
							'n'=>$k,
							'img'=>$config['http_domain'] . $v['_']
						);
					}
				}
				//если новый загрузил документы
				if ($post['status']==9) {
					if ($api['user']['licenses'] AND $api['user']['docs']) {
						$post['status'] = 11;
						mysql_fn('update',$table,array(
							'id'=>$post['id'],
							'status'=>$post['status']
						));
						mailer('user_review',1,$post);
					}
				}
				pusher('user_documents',1,$post);
			}
		}
		else {
			if ($api['error'] == 0) $api['error'] = 1;
		}
	}
	else $api['error'] = 12;
}
