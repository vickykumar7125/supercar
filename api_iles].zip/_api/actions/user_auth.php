<?php

//$api['token'] = '';

//user auth

$fields = array(
	'email'	=> 'required text',
	'password'=> 'required text',
	//'hash'	=> 'required text',
	'uid'   => 'text',
);

//создание массива $post
$post = form_smart($fields,stripslashes_smart($_REQUEST)); //print_r($post);

//сообщения с ошибкой заполнения
$message = form_validate($fields,$post);

//log_add('login.txt',$post,true);

if (count($message)==0) {
	if ($q = mysql_select("SELECT * FROM users WHERE LOWER(email)='".mb_strtolower(mysql_res($post['email']),'UTF-8') ."'",'row')) {
		if (user_hash_db($q['salt'], $post['password']) == $q['hash']
			OR ($post['password'] == $q['remind_code'] AND $config['datetime']<time_zone($q['remind'],24))
		) {
			//if ($usr['status']>0) {
				//обновляем токен
				//$token = md5(time().$q['hash']);
				$token = $q['token'];
				mysql_fn('update','users',array(
					'id'=>$q['id'],
					//'token'=>$token,
					'uid'=>$post['uid'],
					'remind_code'=>''
				));
				$api['user'] = array(
					'id'=>(int)$q['id'],
					'email'=>$q['email'],
					'phone'=>$q['phone'],
					'name'=>$q['name'],
					'status'=>(int)$q['status'],
					'tiers'=>$q['tiers']
				);
				$api['token'] = $token;

				$_SERVER['HTTP_TOKEN'] = $api['token'];
				$user = user('token');
			/*}
			else {
				$api['error'] = 103;
			}*/
		}
		else {
			$api['error'] = 102;
		}
	}
	else $api['error'] = 101;
}
else $api['error'] = 1;