<?php

if (access('user auth')) {
	$fields = array(
		'subject' => 'required text',
		'text' => 'required text',
	);
	//создание массива $post
	$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
	$message = form_validate($fields, $post);
	//log_add('login.txt',$post,true);
	$post['user'] = $user;
	if (count($message) == 0 AND $api['error'] == 0) {
		mailer('feedback', 1, $post);
	}
	else {
		$api['error'] = 1;
	}
}
else {
	$api['error'] = 11;
}