<?php

$table = 'promotions';

//список
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	if (access('user active')) {
		$fields = array(
			'limit' => 'int',
			'n' => 'int',
			'partner' => 'int'
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		if ($post['limit'] < 1) $post['limit'] = 20;
		if ($post['n'] < 1) $post['n'] = 1;

		$where = '';
		if ($post['partner'] == 1) $where .= " AND promotions.partner=" . $post['partner'] . "";

		if (access('user moder') == false) {
			$where .= ' AND display=1';
		}

		//$api['request'] = $_REQUEST;
		$api['promotions'] = mysql_data(
			"
				SELECT promotions.*,
				p.name partner_name,
				p.phone partner_phone,
				p.location partner_location,
				p.img partner_img
				FROM promotions
				LEFT JOIN partners p ON p.id=promotions.partner
				WHERE 1 $where
				ORDER BY promotions.rank DESC
			",
			"SELECT count(id) FROM " . $table . " WHERE 1 $where",
			$post['limit'],
			$post['n']
		);

		foreach ($api['promotions']['list'] as $k => $v) {
			$api['promotions']['list'][$k] = to_int($v);
			if ($v['partner_img']) {
				$api['promotions']['list'][$k]['partner_img'] = $config['http_domain'] . get_img('partners', array(
						'id'=>(int)$v['partner'],
						'img'=>$v['partner_img']
					));
			}
		}
	}
	else $api['error'] = 12;
}

//создание/редактирование
if($_SERVER['REQUEST_METHOD'] == 'POST' OR $_SERVER['REQUEST_METHOD'] == 'PUT') {
	if (access('user moder')) {
		$fields = array(
			'name' => 'required text',
			'partner'=>'required int',
			'text' => 'required text',
			'terms' => 'required text',
			'display' => 'boolean',
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		if (empty($_REQUEST['display'])) $post['display'] = 1;

		if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
			$post['id'] = $id;
			if ($id < 1) $api['error'] = 411;
		}
		//dd($post);
		//сообщения с ошибкой заполнения
		$message = form_validate($fields, $post);
		//log_add('login.txt',$post,true);
		if (count($message) == 0 AND $api['error'] == 0) {
			if (isset($post['id'])) {
				if ($promotion = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {
					mysql_fn('update', $table, $post);
					$post['code'] = $promotion['code'];
					$post['redeemed'] = $promotion['code'];
				}
				else  $api['error'] = 411;
			}
			else {
				$post['code'] = rand(1000,9999);
				$post['created'] = $config['datetime'];
				$post['redeemed'] = 0;
				if ($post['id'] = mysql_fn('insert', $table, $post)) {

				}
				else {
					$api['error'] = 31;
				}
			}
			if ($api['error'] == 0) {
				$api['promotion'] = to_int($post);
			}
		}
		else {
			if ($api['error'] == 0) $api['error'] = 1;
		}
	}
	else $api['error'] = 12;
}

if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
	if (access('user moder')) {
		$post['id'] = $id;
		//сообщения с ошибкой заполнения
		if ($post['id'] AND $promotion = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {

			//$reservation = mysql_select("SELECT id FROM event_users WHERE event=" . $post['id'], 'string');
			//if ($reservation == 0) {
				mysql_fn('delete', $table, $post);
			//}
			//else $api['error'] = 302;
		}
		else  $api['error'] = 411;
	}
	else  $api['error'] = 12;
}