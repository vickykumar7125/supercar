<?php


$fields = array(
	'name' => 'required text',
	'email' => 'required email',
	'subject' => 'required text',
	'text' => 'required text',
);
//создание массива $post
$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
$message = form_validate($fields, $post);
//log_add('login.txt',$post,true);
if (count($message) == 0 AND $api['error'] == 0) {
	$post['user'] = array(
		'name'=>$post['name'],
		'email'=>$post['email'],
		'phone'=>''
	);
	mailer('feedback', 1, $post);
}
else {
	$api['error'] = 1;
}
