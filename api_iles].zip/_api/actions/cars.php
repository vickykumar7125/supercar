<?php

$table = 'cars';

//список
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	//if (access('user active')) {
		$fields = array(
			'limit' => 'int',
			'n' => 'int',
			'user' => 'int',
			'brand' => 'int',
			'model' => 'int'
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		if ($post['limit'] < 1) $post['limit'] = 20;
		if ($post['n'] < 1) $post['n'] = 1;

		$where = '';
		if ($post['user']) $where .= " AND cars.user='" . $post['user'] . "'";
		if ($post['brand']) $where .= " AND cars.brand='" . $post['brand'] . "'";
		if ($post['model']) $where .= " AND cars.model='" . $post['user'] . "'";
		if (access('user moder')==false) {
			$where.= ' AND cars.user='.$user['id'];
		}
		//$where.= " AND imgs!=''";
		//$api['where'] = $where;

		//$api['request'] = $_REQUEST;
		$api['cars'] = mysql_data(
			"
				SELECT cars.*,
					cm.name model_name,
					cm.img model_img,
					cb.name brand_name,
					cb.img brand_img,
					cc.name color_name
				FROM cars
				LEFT JOIN car_models cm ON cm.id=cars.model
				LEFT JOIN car_brands cb ON cb.id=cars.brand
				LEFT JOIN car_colors cc ON cc.id=cars.color
				WHERE 1 $where
				ORDER BY cars.id
			",
			"SELECT count(id) FROM " . $table . " WHERE 1 $where",
			$post['limit'],
			$post['n']
		);
		foreach ($api['cars']['list'] as $k => $v) {
			$imgs = get_imgs($table,$v);
			$docs = get_imgs($table,$v,'docs');
			$api['cars']['list'][$k] = to_int($v);
			$api['cars']['list'][$k]['imgs'] = array();
			$api['cars']['list'][$k]['docs'] = array();
			$api['cars']['list'][$k]['color_name'] = (string)$v['color_name'];
			if ($v['brand_img']) {
				$api['cars']['list'][$k]['brand_img'] = $config['http_domain'] . get_img('car_brands', array(
					'id'=>(int)$v['brand'],
					'img'=>$v['brand_img']
				));
			}
			if ($v['model_img']) {
				$api['cars']['list'][$k]['model_img'] = $config['http_domain'] . get_img('car_models', array(
					'id'=>(int)$v['model'],
					'img'=>$v['model_img']
				));
			}
			foreach ($imgs as $k1=>$v1) {
				$api['cars']['list'][$k]['imgs'][] = array(
					'n' => $k1,
					'img' => $config['http_domain'].$v1['_']
				);
			}
			foreach ($docs as $k1=>$v1) {
				$api['cars']['list'][$k]['docs'][] = array(
					'n'=>$k1,
					'img'=>$config['http_domain'].$v1['_']
				);
			}
		}
	//} else $api['error'] = 12;
}

//создание/редактирование
if($_SERVER['REQUEST_METHOD'] == 'POST' OR $_SERVER['REQUEST_METHOD'] == 'PUT') {
	if (access('user auth')) {
		$fields = array(
			'brand' => 'required int',
			'model' => 'required int',
			'color' => 'required int',
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);

		$fields_img = array(
			'imgs_add' => 'array_string',
			'imgs_del' => 'string_int',
			'docs_add' => 'array_string',
			'docs_del' => 'string_int'
		);
		$images = form_smart($fields_img, stripslashes_smart($_REQUEST)); //print_r($post);
		if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
			$post['id'] = $id;
//			echo $id;
			if ($id < 1) $api['error'] = 311;
		}
		//dd($post);
		//сообщения с ошибкой заполнения
		$message = form_validate($fields, $post);
		//log_add('login.txt',$post,true);
		if (count($message) == 0 AND $api['error'] == 0) {
			if (isset($post['id'])) {
				if ($car = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {
					if (access('user moder')==false) {
						if ($car['user']!=$user['id']) {
							$api['error'] = 12;
						}
					}
					if ($api['error']==0) {
						mysql_fn('update', $table, $post);
						$post['imgs'] = $car['imgs'];
						$post['docs'] = $car['docs'];
						$post['user'] = $car['user'];
					}
				}
				else  $api['error'] = 311;
			}
			else {
				$post['created'] = $config['datetime'];
				$post['user'] = $user['id'];
				if ($post['id'] = mysql_fn('insert', $table, $post)) {
					$post['imgs'] = '';
					$post['docs'] = '';
				}
				else {
					$api['error'] = 31;
				}
			}
			if ($api['error'] == 0) {

				//загрузка/удаление картинок
				//$api['imgs'] = $images;
				$post = api_imgs($table, $post, 'imgs', $images);
				$post = api_imgs($table, $post, 'docs', $images);
				$api['car'] = to_int($post);
				$api['car']['imgs'] = array();
				if ($post['imgs']) {
					$imgs = get_imgs ($table, $post);
					foreach ($imgs as $k=>$v) {
						$api['car']['imgs'][] = array(
							'n'=>$k,
							'img'=>$config['http_domain'] . $v['_']
						);
					}
				}
				$api['car']['docs'] = array();
				if ($post['docs']) {
					$docs = get_imgs ($table, $post,'docs');
					foreach ($docs as $k=>$v) {
						$api['car']['docs'][] = array(
							'n'=>$k,
							'img'=>$config['http_domain'] . $v['_']
						);
					}
				}

				$usr = $user;
				if ($post['user']!=$user['id']) {
					$usr = mysql_select("SELECT * FROM users WHERE id=".$post['user'],'row');
				}
				pusher('car_updated',1,$usr);

			}
		}
		else {
			if ($api['error'] == 0) $api['error'] = 1;
		}
	}
	else $api['error'] = 12;
}

if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
	if (access('user auth')) {
		$post['id'] = $id;
		//сообщения с ошибкой заполнения
		if ($post['id'] AND $car = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {
			if (access('cars delete',$car)) {
				$reservation = mysql_select("SELECT id FROM event_users WHERE car=" . $post['id'], 'string');
				if ($reservation == 0) {
					mysql_fn('delete', $table, $post);
					$relative = 'files/' . $table . '/' . $post['id'] . '/';
					$path = ROOT_DIR . $relative;
					if (is_dir($path)) {
						delete_all($path);
						if (is_dir($path)) {

						}
					}
					if (!is_dir($path)) {
						//v1.3.17 - удаление превью
						if (isset($config['_imgs'][$table])) {
							foreach ($config['_imgs'][$table] as $k => $v) {
								$path = ROOT_DIR . '_imgs/' . $v . '/' . $relative;
								delete_all($path);
							}
						}
					}
				}
				else $api['error'] = 302;
			}
			else {
				$api['error'] = 12;
			}
		}
		else  $api['error'] = 311;
	}
	else  $api['error'] = 12;
}