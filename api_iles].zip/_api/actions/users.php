<?php

$table = 'users';

//список
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	if (access('user auth')){
		$fields = array(
			'id'=>'int',
			'limit' => 'int',
			'n' => 'int',
			'tier' => 'int',
			'status' => 'int',
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);

		$where = 'id!=1';
		//пользователь видит только себя
		if (access('user moder') == false) {
			$where .= " AND id=" . $user['id'];
		}
		if ($post['id']) $where .= " AND id=" . $post['id'];
		if ($post['limit'] < 1) $post['limit'] = 20;
		if ($post['n'] < 1) $post['n'] = 1;
		if ($post['tier']) $where .= " AND FIND_IN_SET (" . $post['tier'].",tiers)";
		if ($post['status']) $where .= " AND status=" . $post['status'];
		//$api['request'] = $_REQUEST;
		$api['users'] = mysql_data(
			"SELECT id,id2,created,expiry,name,email,phone,tiers,status,img,docs,licenses
				FROM " . $table . " WHERE $where ORDER BY created DESC",
			"SELECT count(id) FROM " . $table . " WHERE $where",
			$post['limit'],
			$post['n']
		);
		foreach ($api['users']['list'] as $k => $v) {
			$api['users']['list'][$k] = to_int($v);
			$api['users']['list'][$k]['phone'] = (string)$api['users']['list'][$k]['phone'];
			$api['users']['list'][$k]['img'] = $v['img'] ? $config['http_domain'] . get_img($table, $v) : '';


			$api['users']['list'][$k]['docs'] = array();
			if ($v['docs']) {
				$imgs = get_imgs ($table, $v,'docs');
				foreach ($imgs as $k1=>$v1) {
					$api['users']['list'][$k]['docs'][] = array(
						'n'=>$k1,
						'img'=>$config['http_domain'] . $v1['_']
					);
				}
			}
			$api['users']['list'][$k]['licenses'] = array();
			if ($v['licenses']) {
				$imgs = get_imgs ($table, $v,'licenses');
				foreach ($imgs as $k1=>$v1) {
					$api['users']['list'][$k]['licenses'][] = array(
						'n'=>$k1,
						'img'=>$config['http_domain'] . $v1['_']
					);
				}
			}
		}

	}
	else {
		$api['error'] = 12;
	}
}


//создание/редактирование
if($_SERVER['REQUEST_METHOD'] == 'POST' OR $_SERVER['REQUEST_METHOD'] == 'PUT') {
	if (access('user auth')) {
		//добавлять пользователя может только админ
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			if (access('user moder') == false) $api['error'] = 12;
		}
		if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
			//если не админ то только себя можно редактировать
			if (access('user moder') == false) {
				if ($user['id'] != $id) {
					$api['error'] = 12;
				}
			}
		}
		if ($api['error'] == 0) {
			$fields = array(
				'name' => 'required text',
				'email' => 'required text',
				'phone' => 'text',
				'password'=>'text'
				//'img_add'=>'text',
				//'img_del'=>'int'
			);
			if (access('user moder')) {
				$fields['status'] = 'required int';
				$fields['tiers'] = 'required string_int';
				$fields['expiry'] = 'text';
			}
			//создание массива $post
			$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);

			if ($post['password'] OR $_SERVER['REQUEST_METHOD'] == 'POST') {
				$post['salt'] = md5(time());
				//новый хеш
				$post['hash'] = user_hash_db($post['salt'], $post['password']);
				$post['token'] = md5(time() . $q['hash']);
			}
			unset($post['password']);

			$fields_img = array(
				'img_add' => 'text',
				'img_del' => 'int'
			);
			$images = form_smart($fields_img, stripslashes_smart($_REQUEST)); //print_r($post);

			if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
				$post['id'] = $id;
				if ($id < 1) $api['error'] = 121;
			}

			//добавление
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
				//проверка существования мыла
				$num_rows = mysql_select("SELECT id FROM users WHERE email = '" . mysql_res(strtolower($post['email'])) . "'  LIMIT 1", 'num_rows');
				if ($num_rows == 1) {
					$api['error'] = 111;
				}
				//проверка существования телефона
				if ($post['phone']) {
					$num_rows = mysql_select("SELECT id FROM users WHERE phone = '" . mysql_res(strtolower($post['phone'])) . "'  LIMIT 1", 'num_rows');
					if ($num_rows == 1)
						$api['error'] = 114;
				}
			}


			//dd($post);
			//сообщения с ошибкой заполнения
			$message = form_validate($fields, $post);
			//$api['message'] = $message;
			//log_add('login.txt',$post,true);
			if (count($message) == 0 AND $api['error'] == 0) {
				if (isset($post['id'])) {
					if ($usr = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {
						if (empty($post['token'])) {
							$post['token'] = $usr['token'];
						}

						//проверка существования мыла
						$num_rows = mysql_select("SELECT id FROM users WHERE id!=".$usr['id']." AND email = '" . mysql_res(strtolower($post['email'])) . "'  LIMIT 1", 'num_rows');
						if ($num_rows == 1) {
							$api['error'] = 111;
						}
						//проверка существования телефона
						if ($post['phone']) {
							$num_rows = mysql_select("SELECT id FROM users WHERE id!=".$usr['id']." AND phone = '" . mysql_res(strtolower($post['phone'])) . "'  LIMIT 1", 'num_rows');
							if ($num_rows == 1)
								$api['error'] = 114;
						}

						//v1.3.3 - разрешить null
						$config['mysql_null'] = true;
						if ($post['phone'] == '') $post['phone'] = null;

						mysql_fn('update', $table, $post);
						$post['img'] = $usr['img'];
					}
					else  $api['error'] = 121;
				}
				else {
					$post['created'] = $config['datetime'];
					if ($post['id'] = mysql_fn('insert', $table, $post)) {
						$post['img'] = '';
					}
					else {
						$api['error'] = 31;
					}
				}
				if ($api['error'] == 0) {
					//загрузка/удаление картинок
					$post = api_img($table, $post, 'img', $images);
					$api['user'] = to_int($post);
					if ($post['img']) {
						$api['user']['img'] = $config['http_domain'] . get_img($table, $post);
					}
					$api['user']['docs'] = array();
					if ($post['docs']) {
						$imgs = get_imgs($table, $post, 'docs');
						foreach ($imgs as $k => $v) {
							$api['user']['docs'][] = array(
								'n' => $k,
								'img' => $config['http_domain'] . $v['_']
							);
						}
					}
					$api['user']['licenses'] = array();
					if ($post['licenses']) {
						$imgs = get_imgs($table, $post, 'licenses');
						foreach ($imgs as $k => $v) {
							$api['user']['licenses'][] = array(
								'n' => $k,
								'img' => $config['http_domain'] . $v['_']
							);
						}
					}
					$api['token'] = $post['token'];

					//рассылка уведомления
					if (@$post['status']==1) {
						if (empty($usr) OR $usr['status']!=$post['status']) {
							$api['mailer'] = 'user_active';
							mailer('user_active',1,$post,$post['email']);
						}
					}
					if (@$post['status']==12) {
						if (empty($usr) OR $usr['status']!=$post['status']) {
							$api['mailer'] = 'user_awaiting';
							mailer('user_awaiting',1,$post,$post['email']);
						}
					}
				}

			}
			else {
				if ($api['error'] == 0) $api['error'] = 1;
			}
		}
	}
	else $api['error'] = 12;
}

if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
	if (access('user moder')) {
		$post['id'] = $id;
		//сообщения с ошибкой заполнения
		if ($post['id'] AND $usr = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {

			$reservation = mysql_select("SELECT id FROM event_users WHERE user=" . $post['id'], 'string');
			if ($reservation) {
				$api['error'] = 302;
			}

			$cars = mysql_select("SELECT id FROM cars WHERE user=" . $post['id'], 'string');
			if ($cars) {
				$api['error'] = 212;
			}
			if ($api['error']==0) {
				mysql_fn('delete', $table, $post);
				$relative = 'files/' . $table . '/' . $post['id'] . '/';
				$path = ROOT_DIR . $relative;
				if (is_dir($path)) {
					delete_all($path);
					if (is_dir($path)) {

					}
				}
				if (!is_dir($path)) {
					//v1.3.17 - удаление превью
					if (isset($config['_imgs'][$table])) {
						foreach ($config['_imgs'][$table] as $k => $v) {
							$path = ROOT_DIR . '_imgs/' . $v . '/' . $relative;
							delete_all($path);
						}
					}
				}
			}
			else $api['error'] = 302;
		}
		else  $api['error'] = 301;
	}
	else  $api['error'] = 12;
}