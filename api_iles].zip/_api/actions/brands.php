<?php

$table = 'car_brands';

//список
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	$fields = array(
		'limit' => 'int',
		'n' => 'int'
	);
	//создание массива $post
	$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
	if ($post['limit'] < 1) $post['limit'] = 20;
	if ($post['n'] < 1) $post['n'] = 1;

	$where = '';
	if (access('user moder')==false) {
		$where.= ' AND display=1';
	}

	$api['brands'] = mysql_data(
		"SELECT * FROM ".$table." WHERE 1 $where ORDER BY rank DESC,name",
		"SELECT count(id) FROM ".$table." WHERE 1 $where",
		$post['limit'],
		$post['n']
	);
	foreach ($api['brands']['list'] as $k => $v) {
		$api['brands']['list'][$k] = to_int($v);
		$api['brands']['list'][$k]['img'] = $v['img'] ? $config['http_domain'] . get_img($table, $v) : '';
	}
}

//создание/редактирование
if($_SERVER['REQUEST_METHOD'] == 'POST' OR $_SERVER['REQUEST_METHOD'] == 'PUT') {
	if (access('user moder')) {
		$fields = array(
			'name' => 'required text',
			'rank' => 'int',
			'display' => 'boolean',
			//'img_add'=>'text',
			//'img_del'=>'int'
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		if ($_SERVER['REQUEST_METHOD'] == 'PUT' AND empty($_REQUEST['rank'])) unset($post['rank']);
		if (empty($_REQUEST['display'])) $post['display'] = 1;

		$fields_img = array(
			'img_add' => 'text',
			'img_del' => 'int',
		);
		$images = form_smart($fields_img, stripslashes_smart($_REQUEST)); //print_r($post);

		if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
			$post['id'] = $id;
			if ($id < 1) $api['error'] = 201;
		}
		//dd($post);
		//сообщения с ошибкой заполнения
		$message = form_validate($fields, $post);
		//log_add('login.txt',$post,true);
		if (count($message) == 0 AND $api['error'] == 0) {
			$brand = array();
			if (isset($post['id'])) {
				if ($brand = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {
					if (empty($post['rank'])) $post['rank'] = $brand['rank'];
					mysql_fn('update', $table, $post);
					$post['img'] = $brand['img'];
				}
				else  $api['error'] = 201;
			}
			else {
				$post['created'] = $config['datetime'];
				if ($post['id'] = mysql_fn('insert', $table, $post)) {
					$post['img'] = '';
				}
				else {
					$api['error'] = 31;
				}
			}
			if ($api['error'] == 0) {
				//загрузка/удаление картинок
				$post = api_img($table, $post, 'img', $images);
				$api['brand'] = to_int($post);
				if ($post['img']) {
					$api['brand']['img'] = $config['http_domain'] . get_img($table, $post);
				}
			}

			/*
			if ($api['error']==0) {
				//загрузка файла
				if (@$_FILES['img']['tmp_name']) {
					$post['img'] = file_upload('img', '/files/car_brands/' . $post['id'] . '/img/', array('' => 'resize 1000x1000'));
					if ($post['img'] != $brand['img']) {
						mysql_fn('update', 'car_brands', $post);
					}
				} else $post['img'] = $brand['img'];
			}
			*/
		} else {
			if ($api['error'] == 0) $api['error'] = 1;
		}
	}
	else $api['error'] = 12;
}

if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
	if (access('user moder')) {
		$post['id'] = $id;
		//сообщения с ошибкой заполнения
		if ($post['id'] AND $brand = mysql_select("SELECT * FROM car_brands WHERE id=" . $post['id'], 'row')) {
			$model = mysql_select("SELECT id FROM car_models WHERE brand=" . $post['id'] . " LIMIT 1", 'string');
			if ($model == 0) {
				$car = mysql_select("SELECT id FROM cars WHERE brand=" . $post['id'] . " LIMIT 1", 'string');
				if ($car == 0) {
					mysql_fn('delete', 'car_brands', $post);
					$relative = 'files/car_brands/' . $post['id'] . '/';
					$path = ROOT_DIR . $relative;
					if (is_dir($path)) {
						delete_all($path);
						if (is_dir($path)) {

						}
					}
					if (!is_dir($path)) {
						//v1.3.17 - удаление превью
						if (isset($config['_imgs']['car_brands'])) {
							foreach ($config['_imgs']['car_brands'] as $k => $v) {
								$path = ROOT_DIR . '_imgs/' . $v . '/' . $relative;
								delete_all($path);
							}
						}
					}
				} else $api['error'] = 212;
			} else $api['error'] = 211;
		} else  $api['error'] = 201;
	}
	else $api['error'] = 12;
}