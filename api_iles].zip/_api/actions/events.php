<?php

$table = 'events';

//список
if($_SERVER['REQUEST_METHOD'] == 'GET') {
	if (access('user active')) {
		$fields = array(
			'limit' => 'int',
			'n' => 'int',
			'type' => 'int',
			'id'=>'int'
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		if ($post['limit'] < 1) $post['limit'] = 20;
		if ($post['n'] < 1) $post['n'] = 1;

		$where = '';
		if ($post['type'] == 1) $where .= " AND date>='" . $config['date'] . "'";
		if ($post['type'] == 2) $where .= " AND date<'" . $config['date'] . "'";

		if (access('user moder') == false) {
			$where .= ' AND display=1';
			if ($user['tiers']) {
				$tiers = explode(',', $user['tiers']);
				$where2 = array();
				foreach ($tiers as $k=>$v) {
					$where2[]  = " FIND_IN_SET ('".$v."',tiers) ";
				}
				$where.= " AND (".implode(' OR ',$where2).")";
			}
			else $where.= " AND 1=2";
		}
		if ($post['id']) $where.=" AND events.id=".$post['id'];

		//$api['where'] = $where;

		//$api['request'] = $_REQUEST;
		$api['events'] = mysql_data(
			"SELECT events.*, eu.id as reservation FROM " . $table . "
			LEFT JOIN event_users eu ON eu.event=events.id AND eu.user=".$user['id']."
			WHERE 1 $where ORDER BY events.date, events.start",
			"SELECT count(id) FROM " . $table . " WHERE 1 $where",
			$post['limit'],
			$post['n']
		);
		$partners = mysql_select("SELECT id,name,img FROM partners ORDER BY name",'rows_id');
		foreach ($partners as $k=>$v) {
			if ($v['img']) $partners[$k]['img'] =  $config['http_domain'] .get_img('partners',$v);
		}
		foreach ($api['events']['list'] as $k => $v) {
			$api['events']['list'][$k] = to_int($v);
			$api['events']['list'][$k]['reservation'] = intval($v['reservation']);
			$users = mysql_select("
				SELECT u.id,u.name,u.img,
					eu.guests,
					c.brand, cb.name brand_name, cb.img brand_img,
					cm.name model_name
				FROM users u, event_users eu
				LEFT JOIN cars c ON c.id=eu.car
				LEFT JOIN car_models cm ON cm.id=c.model
				LEFT JOIN car_brands cb ON cb.id=c.brand
				WHERE eu.event=".$v['id']." AND u.id=eu.user
				ORDER BY u.id
			",'rows');
			$brands = array();
			$brand_ids = array();
			if ($users) foreach ($users as $k1=>$v1) {
				$users[$k1] = to_int($v1);
				$brand = array(
					'id'=>(int)$v1['brand'],
					'name'=>$v1['brand_name'],
					'img'=>$v1['brand_img']
				);
				if ($brand['img']) {
					$brand['img'] = $config['http_domain'] .get_img('car_brands',$brand);
				}
				if (!isset($brand_ids[$brand['id']])) {
					$brands[] = $brand;
					$brand_ids[$brand['id']] = $brand['id'];
				}
				$users[$k1]['img'] = $v1['img'] ? $config['http_domain'] .get_img('users',$v1):'';
				unset($users[$k1]['brand_img']);
				unset($users[$k1]['brand']);
			}
			$api['events']['list'][$k]['img'] = $v['img'] ? $config['http_domain'] . get_img($table, $v) : '';

			$api['events']['list'][$k]['status'] = event_status($v);

			$api['events']['list'][$k]['users'] = $users;
			$api['events']['list'][$k]['brands'] = $brands;

			if ($v['partners']) {
				$prs = explode(',',$v['partners']);
				$api['events']['list'][$k]['partners'] = array();
				foreach ($prs as $k1=>$v1) {
					if (isset($partners[$v1])) {
						$api['events']['list'][$k]['partners'][] = to_int($partners[$v1]);
					}
				}
			}
			else {
				$api['events']['list'][$k]['partners'] = array();
			}
		}
	}
	else $api['error'] = 12;
}

//создание/редактирование
if($_SERVER['REQUEST_METHOD'] == 'POST' OR $_SERVER['REQUEST_METHOD'] == 'PUT') {
	if (access('user moder')) {
		$fields = array(
			'name' => 'required text',
			'text' => 'required text',
			'date' => 'required text',
			'start' => 'required text',
			'end' => 'required text',
			'tiers' => 'required string_int',
			'partners' => 'string_int',
			'limit_cars' => 'int',
			'limit_guests' => 'int',
			'display' => 'boolean',
			//'img_add'=>'text',
			//'img_del'=>'int'
		);
		//создание массива $post
		$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);
		$post['start'] = hours_minutes ($post['start']);
		$post['end'] = hours_minutes ($post['end']);
		if (empty($_REQUEST['display'])) $post['display'] = 1;

		$fields_img = array(
			'img_add' => 'text',
			'img_del' => 'int'
		);
		$images = form_smart($fields_img, stripslashes_smart($_REQUEST)); //print_r($post);

		if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
			$post['id'] = $id;
			if ($id < 1) $api['error'] = 301;
		}
		//dd($post);
		//сообщения с ошибкой заполнения
		$message = form_validate($fields, $post);
		//log_add('login.txt',$post,true);
		if (count($message) == 0 AND $api['error'] == 0) {
			if (isset($post['id'])) {
				if ($event = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {
					mysql_fn('update', $table, $post);
					$post['img'] = $event['img'];
				} else  $api['error'] = 301;
			}
			else {
				$post['created'] = $config['datetime'];
				if ($post['id'] = mysql_fn('insert', $table, $post)) {
					$post['img'] = '';
				}
				else {
					$api['error'] = 31;
				}
			}
			if ($api['error'] == 0) {
				//загрузка/удаление картинок
				$post = api_img($table, $post, 'img', $images);
				$api['event'] = to_int($post);
				if ($post['img']) {
					$api['event']['img'] = $config['http_domain'] . get_img($table, $post);
				}
			}

		} else {
			if ($api['error'] == 0) $api['error'] = 1;
		}
	}
	else $api['error'] = 12;
}

if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
	if (access('user moder')) {
		$post['id'] = $id;
		//сообщения с ошибкой заполнения
		if ($post['id'] AND $event = mysql_select("SELECT * FROM " . $table . " WHERE id=" . $post['id'], 'row')) {

			$reservation = mysql_select("SELECT id FROM event_users WHERE event=" . $post['id'], 'string');
			if ($reservation == 0) {
				mysql_fn('delete', $table, $post);
				$relative = 'files/' . $table . '/' . $post['id'] . '/';
				$path = ROOT_DIR . $relative;
				if (is_dir($path)) {
					delete_all($path);
					if (is_dir($path)) {

					}
				}
				if (!is_dir($path)) {
					//v1.3.17 - удаление превью
					if (isset($config['_imgs'][$table])) {
						foreach ($config['_imgs'][$table] as $k => $v) {
							$path = ROOT_DIR . '_imgs/' . $v . '/' . $relative;
							delete_all($path);
						}
					}
				}
			}
			else $api['error'] = 302;
		}
		else  $api['error'] = 301;
	}
	else  $api['error'] = 12;
}