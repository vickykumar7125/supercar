<?php

//$api['token'] = '';

//user auth

if (access('user auth')) {
	$fields = array(
		'uid' => 'required text',
	);

	//создание массива $post
	$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);

	//сообщения с ошибкой заполнения
	$message = form_validate($fields, $post);

	//log_add('login.txt',$post,true);

	if (count($message) == 0) {
		$post['id'] = $user['id'];
		mysql_fn('update', 'users', $post);
	}
	else $api['error'] = 1;
}
else $api['error'] = 12;