<?php

if (access('user active')) {
	$fields = array(
		'promotion' => 'required text',
		'code'=>'required int',
	);
	//создание массива $post
	$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);

	//dd($post);
	//сообщения с ошибкой заполнения
	$message = form_validate($fields, $post);
	//log_add('login.txt',$post,true);
	if (count($message) == 0) {
		if ($promotion = mysql_select("SELECT * FROM promotions WHERE id=" . $post['promotion'], 'row')) {
			if ($promotion['code']==$post['code']) {
				$promotion['redeemed']++;
				mysql_fn('update', 'promotions', $promotion);
				$api['promotion'] = $promotion;
			}
			else $api['error'] = 411;
		}
		else  $api['error'] = 411;

	}
	else $api['error'] = 1;
}
else $api['error'] = 12;
