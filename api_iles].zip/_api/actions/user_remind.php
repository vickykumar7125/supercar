<?php

//todo доделать или сброс пароля или вход по коду

//user auth

$fields = array(
	'email'	=> 'required text',
);

//создание массива $post
$post = form_smart($fields,stripslashes_smart($_REQUEST)); //print_r($post);

//сообщения с ошибкой заполнения
$message = form_validate($fields,$post);

if (!filter_var($post['email'],FILTER_VALIDATE_EMAIL)) {
	$api['error'] = 112;
}
//log_add('login.txt',$post,true);

if ($api['error']==0) {
	if (count($message) == 0) {
		if ($q = mysql_select("
			SELECT *
			FROM users
			WHERE email = '".mysql_res(strtolower($post['email']))."'
			LIMIT 1
		",'row')) {
			$code = md5(time().$q['email']);
			$code = substr($code,0,7);
			$usr = array(
				'id'=>$q['id'],
				'remind' => $config['datetime'],
				'remind_code' => $code
			);
			mysql_fn('update','users',$usr);
			//$api['remind_code'] = $code;
			//
			mailer('remind',false,$usr,$post['email']);
		}
		else {
			$api['error'] = 115;
		}
	}
	else {
		$api['error'] = 1;
	}
}