<?php

//$api['token'] = '';

//user auth
if (access('user moder')) {
	$fields = array(
		'id' => 'required int',
		'text' => 'required text',
	);

	//создание массива $post
	$post = form_smart($fields, stripslashes_smart($_REQUEST)); //print_r($post);

	//сообщения с ошибкой заполнения
	$message = form_validate($fields, $post);

	if (count($message) == 0) {
		if ($usr = mysql_select("SELECT * FROM users WHERE id=".$post['id'], 'row')) {
			$data = array(
				'id'=>$usr['id'],
				'status'=>23
			);
			mysql_fn('update','users',$data);
			$post['text'] = nl2br($post['text']);
			$usr = array_merge($usr,$post);
			mailer('user_suspended',1,$usr,$usr['email']);
		}
		else $api['error'] = 121;
	}
	else $api['error'] = 1;
}
else $api['error'] = 12;