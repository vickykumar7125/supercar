<?php
ini_set('max_execution_time', 1000);
// загрузка настроек *********************************************************
define('ROOT_DIR', dirname(__FILE__).'/../');
require_once(ROOT_DIR.'_config.php');	//динамические настройки
require_once(ROOT_DIR.'_config2.php');	//установка настроек
set_error_handler('error_handler');

// загрузка функций **********************************************************
require_once(ROOT_DIR.'functions/mail_func.php');	//функции админки
require_once(ROOT_DIR.'functions/auth_func.php');	//функции авторизации
require_once(ROOT_DIR.'functions/common_func.php');	//общие функции
require_once(ROOT_DIR.'functions/file_func.php');	//функции для работы с файлами
require_once(ROOT_DIR.'functions/html_func.php');	//функции для работы нтмл кодом
require_once(ROOT_DIR.'functions/form_func.php');	//функции для работы со формами
require_once(ROOT_DIR.'functions/image_func.php');	//функции для работы с картинками
require_once(ROOT_DIR.'functions/lang_func.php');	//функции словаря
require_once(ROOT_DIR.'functions/mysql_func.php');	//функции для работы с БД
require_once(ROOT_DIR.'functions/string_func.php');	//функции для работы со строками
require_once(ROOT_DIR.'functions/api_func.php');	//функции почты
require_once(ROOT_DIR.'functions/push_func.php');	//функции почты

//аутентификация - создание массива с данными пользователя
$user = user('auth'); //print_r($user);

lang(1);

$request_url = explode('?',$_SERVER['REQUEST_URI'],2); //dd($request_url);
//создание массива $u
$u = explode('/',$request_url[0]);

$api = array(
	'error'=>0,
	'error_text'=>''
//	'action'=>$post['action']
);
header('Content-type: application/json; charset='.$config['charset']);
$action = preg_replace('~[^_a-z]+~u', '-', $u[2]);    //удаление лишних символов
$id = intval(@$u[3]);
if (file_exists(ROOT_DIR.'_api/actions/'.$action.'.php')) {

	//log_add('post.txt',$config['datetime'].' '.$action.' '.$_SERVER['REQUEST_METHOD']);
	//log_add('post.txt',$_SERVER);
	//log_add('post.txt',$_POST);
	//log_add('post.txt',file_get_contents('php://input'));

	//подмена меременной $_REQUEST
	if($_SERVER['REQUEST_METHOD'] == 'PUT') {
		parse_http_request($_REQUEST);
	}
	if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
		parse_http_request($_REQUEST);
	}
	if($_SERVER['REQUEST_METHOD'] == 'POST') {
		if (count($_POST)==0) {
			$postData = file_get_contents('php://input');
			$_REQUEST = json_decode($postData, true);
		}
	}

	if ($user = user('token') OR in_array($action,array(
		'user_registration','user_auth','user_remind',
		'past_events','brands','models',
		'pages',
		'feedback_site','country'
	))) {

		//проверка прав доступа к апи
		/*if (in_array($action,array(
			'tiers','brands','color','models','events')
			)) {
			if (!access('user admin')) $api['error'] = 12;
		}*/

		if ($api['error']==0) {
			include(ROOT_DIR . '_api/actions/' . $action . '.php');
		}
	}
	else $api['error'] = 11;
}
else $api['error'] = 2;




if (!$api AND !isset($api['error'])) {
	$api['error'] = 1;
}

//header('Content-type: application/json; charset='.$config['charset']);
if ($api['error'] == 201) {
	//header('HTTP/1.1 401 Unauthorized');
}
if ($api['error'] AND isset($config['api_errors'][$api['error']])) $api['error_text'] = $config['api_errors'][$api['error']];


if (@$_REQUEST['debug']) {
	//echo '<pre>';
	print_r($api);
	//echo '<pre>';
}
else echo json_encode($api);