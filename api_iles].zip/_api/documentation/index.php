<?php

define('ROOT_DIR', dirname(__FILE__).'/../../');
require_once(ROOT_DIR.'_config.php');	//динамические настройки
require_once(ROOT_DIR.'_config2.php');	//установка настроек

//require_once(ROOT_DIR.'/functions/admin_func.php');	//функции админки
require_once(ROOT_DIR.'/functions/auth_func.php');	//функции авторизации
require_once(ROOT_DIR.'/functions/common_func.php');	//общие функции
//require_once(ROOT_DIR.'/functions/file_func.php');	//функции для работы с файлами
require_once(ROOT_DIR.'/functions/html_func.php');	//функции для работы нтмл кодом
require_once(ROOT_DIR.'/functions/form_func.php');	//функции для работы со формами
//require_once(ROOT_DIR.'/functions/image_func.php');	//функции для работы с картинками
require_once(ROOT_DIR.'/functions/lang_func.php');	//функции словаря
require_once(ROOT_DIR.'/functions/mail_func.php');	//функции почты
require_once(ROOT_DIR.'/functions/mysql_func.php');	//функции для работы с БД
require_once(ROOT_DIR.'/functions/string_func.php');	//функции для работы со строками

$connect = mysql_connect_db();
//аутентификация - создание массива с данными пользователя
$user = user('auth'); //print_r($user);
//dd($user);

$errors = @$config['api_errors'];

$token = '123';

$pages = array(
	'Main' => array(
		'info_about'		=> 'introduction',
		'info_database'     => 'database',
		'info_users'        => 'user statuses',
		'pages_get'         => 'get pages',
		'feedback_post'         => 'post feedback',
		//'dashboard'         => 'dashboard',
	),
	'Users' => array(
		'user_auth'			=> 'post /user_auth/',
		'user_uid'			=> 'post /user_uid/',
		'user_registration'	=> 'post /user_registration/',
		'user_remind'	    => 'post /user_remind/',
		'user_password'	    => 'post /user_password/',
		'user_suspended'    => 'post /user_suspended/',
		'user_docs_id_put'  => 'put /user_docs/{id}/',
		'users_post'        => 'post /users/',
		'users_get'         => 'get /users/',
		//'users_id_get'    => 'get /users/{id}',
		'users_id_put'      => 'put /users/{id}/',
		'users_id_delete'   => 'delete /users/{id}/',
	),
	'User tiers' => array(
		'tiers_post'        => 'post /tiers/',
		'tiers_get'            => 'get /tiers/',
		//'tiers_id_get'            => 'get /tiers/{id}',
		'tiers_id_put'         => 'put /tiers/{id}/',
		'tiers_id_delete'      => 'delete /tiers/{id}/',
	),
	'Cars' => array(
		'cars_post'        => 'post /cars/',
		'cars_get'            => 'get /cars/',
		//'cars_id_get'            => 'get /cars/{id}',
		'cars_id_put'         => 'put /cars/{id}/',
		'cars_id_delete'      => 'delete /cars/{id}/',
	),
	'Car brands' => array(
		'brands_post'        => 'post /brands/',
		'brands_get'            => 'get /brands/',
		//'brands_id_get'            => 'get /brands/{id}',
		'brands_id_put'         => 'put /brands/{id}/',
		'brands_id_delete'      => 'delete /brands/{id}/',
	),
	'Car models' => array(
		'models_post'        => 'post /models/',
		'models_get'            => 'get /models/',
		//'models_id_get'            => 'get /models/{id}',
		'models_id_put'         => 'put /models/{id}/',
		'models_id_delete'      => 'delete /models/{id}/',
	),
	'Car colors' => array(
		'colors_post'        => 'post /colors/',
		'colors_get'            => 'get /colors/',
		//'colors_id_get'            => 'get /colors/{id}',
		'colors_id_put'         => 'put /colors/{id}/',
		'colors_id_delete'      => 'delete /colors/{id}/',
	),
	'Events' => array(
		'events_post'        => 'post /events/',
		'events_get'            => 'get /events/',
		//'events_id_get'            => 'get /events/{id}',
		'events_id_put'         => 'put /events/{id}/',
		'events_id_delete'      => 'delete /events/{id}/',
	),
	'Past events' => array(
		'past_events_post'        => 'post /past_events/',
		'past_events_get'            => 'get /past_events/',
		//'events_id_get'            => 'get /events/{id}',
		'past_events_id_put'         => 'put /past_events/{id}/',
		'past_events_id_delete'      => 'delete /past_events/{id}/',
	),
	'Checkpoints' => array(
		'checkpoints_post'        => 'post /checkpoints/',
		'checkpoints_get'            => 'get /checkpoints/',
		//'checkpoints_id_get'            => 'get /checkpoints/{id}',
		'checkpoints_id_put'         => 'put /checkpoints/{id}/',
		'checkpoints_id_delete'      => 'delete /checkpoints/{id}/',
	),
	'Reservations' => array(
		'reservations_post'        => 'post /reservations/',
		'reservations_get'            => 'get /reservations/',
		'reservations_delete'            => 'delete /reservations/',
		'reservation_checks_post'        => 'post /reservation_checks/',
	),
	'Partners' => array(
		'partners_post'        => 'post /partners/',
		'partners_get'            => 'get /partners/',
		//'partners_id_get'            => 'get /partners/{id}',
		'partners_id_put'         => 'put /partners/{id}/',
		'partners_id_delete'      => 'delete /partners/{id}/',
	),
	'Promotions' => array(
		'promotions_post'        => 'post /promotions/',
		'promotions_get'            => 'get /promotions/',
		//'promotions_id_get'            => 'get /promotions/{id}',
		'promotions_id_put'         => 'put /promotions/{id}/',
		'promotions_id_delete'      => 'delete /promotions/{id}/',
		'promotions_code'        => 'post /promotions_code/',
	),

/*
	'GET' => array(
		'brands'        => 'brands',
		'models'        => 'models',
		'cars'          => 'cars',
	),
	'POST' => array(
		'brand_post'        => 'brand',
		'model_post'        => 'model',
		'car_post'          => 'car',
	),
	'PUT' => array(
		'brand_put'        => 'brand',
		'model_put'        => 'model',
		'car_put'          => 'car',
	),
	/*
	'Profile' => array(
		'user_auth'			=> 'authorization',
		'user_registration'	=> 'registration',
		'user_remind'	    => 'remind',
	),
	'Admin' => array(
		'brands'        => 'brands',
		'brand_edit'    => 'brand edit/new',
		'brand_delete'	=> 'brand delete',

		'models'        => 'models',
		'model_edit'=> 'model edit/new',
		'model_delete'	=> 'model delete',

	),
	'Members' => array(
        'car_edit'	    => 'car edit',
		'car_delete'	=> 'car delete',
		'cars'          => 'cars',
    ),
	*/
);

$page = 'info_about';
$name = 'introduction';
foreach ($pages as $k=>$v) {
	if (array_key_exists(@$_GET['page'],$v)) {
		$page = $_GET['page'];
		$name = $v[$page];
	}
}

include('template.php');

function table ($type,$array) {
	global $errors,$config,$method,$url,$token,$user;
	//include(ROOT_DIR.'_api/documentation/token.php');	//функции авторизации

	$required = $is_token = 0;
	if ($type == 'request') {
		$content = '<h3>API request</h3>';
		$content.= '<pre>'.strtoupper($method).' /_api/'.$url.'/'.'</pre>';
		if ($token) {
			$content .= '<pre>HEADER HTTP_TOKEN : {token}</pre>';
		}
	}
	else {
		$content = '<h3>API answer</h3>';
	}
	if ($array) {

		$content .= '<table class="table">
		<thead>
			<tr>
				<td style="color:#999">key</td>
				<td style="color:#999">type</td>
				<td style="color:#999">description</td>
			<tr>
		</thead>
		<tbody>';
		//dd($array);
		foreach ($array as $k => $v) {
			if (empty($v[1])) {
				if ($k == 'name') $v[1] = 'item name';
				elseif ($k == 'display') $v[1] = 'display or not [0,1], 1 default';
				elseif ($k == 'rank') $v[1] = 'rank for sorting [100,50,10,0,-10]';
				elseif ($k == 'id') $v[1] = 'item id';
				elseif ($k == 'img') $v[1] = 'full path to image';
				elseif ($k == 'img_add') $v[1] = 'new image body in base64';
				elseif ($k == 'img_del') $v[1] = 'delete current image [1 - yes, 0 - no]';
				elseif ($k == 'imgs_add') $v[1] = 'array width new images body in base64';
				elseif ($k == 'imgs_del') $v[1] = 'comma-separated image numbers to be deleted (1,2,3)';
				elseif ($k == 'docs_add') $v[1] = 'array width new images body in base64';
				elseif ($k == 'docs_del') $v[1] = 'comma-separated image numbers to be deleted (1,2,3)';
				elseif ($k == 'licenses_add') $v[1] = 'array width new images body in base64';
				elseif ($k == 'licenses_del') $v[1] = 'comma-separated image numbers to be deleted (1,2,3)';
				elseif ($k == 'date') $v[1] = 'date YYYY-MM-DD';
				elseif ($k == 'start') $v[1] = 'start time HH:MM';
				elseif ($k == 'end') $v[1] = 'end time HH:MM';
				else $v[1] = $k;
			}
			if ($k == 'token') {
				if ($type == 'request') $v = array('string', 'token for authorized requests', true);
				else $v = array('string', 'token for authorized requests');
				$array[$k] = $v;
			}
			$content .= '<tr>';
			// токен выдееляем цветом
			if ($type == 'answer' AND $k == 'token') {
				$content .= '<td  style="color:darkblue">' . $k . '</td>';
				$is_token++;
			}
			/*
			elseif(in_array(@$page,$blue_pages) AND in_array($k,$blue_str)){
	            $content .= '<td  style="color:darkblue">' . $k . '</td>';
	        }
			*/
			// выделение цветом со ссылкой
			elseif (@$v[2] AND $v[2] === true) {
				$content .= '<td  style="color:darkred">' . $k . '</td>';
				$required++;
			} // вывод названия
			else $content .= '<td>' . $k . '</td>';
			// вывод типа массива
			$content .= '<td>' . $v[0] . '</td>';
			// если ответ и выводится дополнительная информация
			if ($type == 'answer' AND @$v[2] AND is_string($v[2])) {
				// если нужно выводить коды ошибок
				if ($k == 'error') {
					$error = explode(',', $v[2]);
					$content .= '<td>' . $v[1];
					foreach ($errors as $e => $t) if (in_array($e, $error)) {
						$content .= '<br>' . $e . ' - ' . $t;
					}
					$content .= '</td>';
				} //если нужно расписать массив
				elseif (($v[0] == 'array' || $v[0] == 'arrays') AND is_array($v[2])) {
					$content .= '<td>' . $v[1] . '</a></td>';
					foreach ($v[2] as $arrk => $arrv) {
						$content .= '</tr>';
						$content .= '<tr>';
						$content .= '<td>:.. ' . $arrk . '</td>';
						$content .= '<td>' . $arrv[0] . '</td>';
						$content .= '<td>' . $arrv[1] . '</td>';
					}
				} // остальная информация
				else {
					$content .= '<td>' . $v[1] . ' <a href="?page=' . $v[2] . '">' . $v[2] . '</a></td>';
				}
			} // для запросов
			elseif ($type == 'request' AND @$v[3] AND is_string($v[3])) {
				$content .= '<td>' . $v[1] . ' <a href="' . $v[3] . '">' . $v[3] . '</a></td>';
			} else $content .= '<td>' . $v[1] . '</td>';
			$content .= '</tr>';

			if (@$v[2] AND is_array($v[2])) foreach ($v[2] as $k1 => $v1) {
				$content .= '<tr>';
				if (empty($v1[1])) $v1[1] = $k1;
				if (@$v1[2] AND $v1[2] === true) {
					$content .= '<td  style="color:darkred">:.. ' . $k1 . '</td>';
					$required++;
				}
				else $content .= '<td>:.. ' . $k1 . '</td>';
				$content .= '<td>' . $v1[0] . '</td>';
				if ($type == 'answer' AND @$v1[2] AND is_string($v1[2])) {
					$content .= '<td>' . $v1[1] . ' <a href="?page=' . $v1[2] . '">' . $v1[2] . '</a></td>';
				}
				else $content .= '<td>' . $v1[1] . '</td>';
				$content .= '</tr>';
				if (@$v1[2] AND is_array($v1[2])) foreach ($v1[2] as $k2 => $v2) {
					if (empty($v2[1])) {
						if ($k2 == 'name') $v2[1] = 'item name';
						elseif ($k2 == 'display') $v2[1] = 'display or not [0,1]';
						elseif ($k2 == 'rank') $v2[1] = 'rank for sorting [100,50,10,0,-10]';
						elseif ($k2 == 'id') $v2[1] = 'item id';
						elseif ($k2 == 'img') $v2[1] = 'full path to image';
						else $v2[1] = $k2;
					}
					$content .= '<tr>';
					if (@$v2[2] AND $v2[2] === true) {
						$content .= '<td  style="color:darkred">:.. ' . $k2 . '</td>';
						$required++;
					}
					else $content .= '<td>&nbsp;&nbsp; :.. ' . $k2 . '</td>';
					$content .= '<td>' . $v2[0] . '</td>';
					$content .= '<td>' . $v2[1] . '</td>';
					$content .= '</tr>';
					if (is_array(@$v2[2])) {
						foreach ($v2[2] as $k3=>$v3) {
							if (empty($v3[1])) {
								if ($k3 == 'name') $v3[1] = 'item name';
								elseif ($k3 == 'display') $v3[1] = 'display or not [0,1]';
								elseif ($k3 == 'rank') $v3[1] = 'rank for sorting [100,50,10,0,-10]';
								elseif ($k3 == 'id') $v3[1] = 'item id';
								elseif ($k3 == 'img') $v3[1] = 'full path to image';
								else $v3[1] = $k3;
							}
							$content .= '<tr>';
							if (@$v3[2] AND $v3[2] === true) {
								$content .= '<td  style="color:darkred">:.. ' . $k3 . '</td>';
								$required++;
							}
							else $content .= '<td>&nbsp;&nbsp; &nbsp;&nbsp; :.. ' . $k3 . '</td>';
							$content .= '<td>' . $v3[0] . '</td>';
							$content .= '<td>' . $v3[1] . '</td>';
							$content .= '</tr>';
						}
					}
				}
			}

		}
		$content .= '</tbody>';
		$content .= '</table>';
		if ($required) $content .= '<small style="color:darkred">* required</small>';
		if ($is_token) $content .= '<small style="color:darkblue">* the token value must be saved on the device and used for the next requests</small>';
	}

	if ($type=='request') {
		if(isset($config['param_table']['form'])){
			$content.= $config['param_table']['form'];
		}
		else{
			//$content.= '<a href="#" class="show_form">Send request</a>';
			$content.= '<form action="/_api/'.$url.'/" method="'.strtoupper($method).'" target="_blank" enctype="multipart/form-data" style="display:none2">';
			$content.= '<h3>Send request</h3>';

			$content.= '
			<div class="form-group"">
				<input style="background:#CBCBCB" class="form-control" onchange="$(this).closest(\'form\').attr(\'action\',$(this).val())" value="/_api/'.$url.'/">
			</div>';
			if ($token) {
				$content.= '
				<div class="form-group"">
					<input style="background:#CBCBCB" class="token form-control" value="'.@$user['token'].'" placeholder="token">
				</div>';
			}
			foreach ($array as $k => $v) {
				if (empty($v[1])) $v[1] = $k;
				$val = '';
				//if ($k=='token') $val = $token;
                if ($v[0]=='array') {
					$content.= '<div class="form-group"><label for="card">'.$v[1].'</label>';
					$content.= '<input class="form-control" name="'.$k.'[]" value="">';
					$content.= '<input class="form-control" name="'.$k.'[]" value="">';
					$content.= '<input class="form-control" name="'.$k.'[]" value="">';
					$content.= '</div>';
				}
				elseif ($v[0]=='file') {
					$content.= '<div class="form-group"><label for="'.$k.'">'.$v[1].'</label>
					<input class="form-control" type="file" name="'.$k.'">
					</div>';
				}
				else {
					$content.= '<div class="form-group"><label for="'.$k.'">'.$v[1].'</label>
					<input class="form-control" name="'.$k.'" value="'.$val.'">
					</div>';
				}
			}
			$content.= '<button type="submit" class="btn btn-primary">Send request</button>';
			$content.= '<br><br><pre style="white-space: pre-wrap;">The query result is displayed here</pre>';
			$content.= '</form>';
			//$content.= '<pre>'.strtoupper($method).': http://'.$_SERVER['HTTP_HOST'].'/_api/'.$url.'/';
			//dd($array);
			$n=0;
//		$num_rows = count($array);
			//dd($array);
			foreach ($array as $k => $v) {
				if (@$v[2]===true) {
					$n++;
					//$content.= ($n>1?'&amp;':'').$k.'='.$v[0].'';
					//if ($k=='token') $content.= $k.'='.$token.'&';
					//else $content.= $k.'='.$v[0].'&';

				}
			}
			//$content.= '</pre>';
		}

	}
	else {
		$content.= '<h3>example</h3>';
		$content.= '<pre>';
		$content.= "\r\n".'{';
		foreach ($array as $k => $v) {
			$content.= "\r\n".'	"'.$k.'":';
			if (@$v[2] AND is_array($v[2])) {
				if ($v[0]=='array') $content.= '{';
				else {
					$content.= "[";
					$content.= "\r\n"."		{";
				}
				foreach ($v[2] as $k1 => $v1) {
					$content.= "\r\n";
					if ($v[0]=='arrays') $content.= '	';
					$content.='		"'.$k1.'":';
					if (@$v1[2] AND is_array($v1[2])) {
						if ($v1[0]=='arrays') {
							$content .= "[";
							$content .= "\r\n";
							if ($v[0]=='arrays') $content.= '	';
							$content.= "			{";
						}
						else $content.= "{";
						foreach ($v1[2] as $k2 => $v2) {
							$content.= "\r\n";
							if ($v[0]=='arrays') $content.= '	';
							if ($v1[0]=='arrays') $content.= '	';
							$content.= '			"'.$k2.'":"'.$v2[0].'",';
						}
						$content .= "\r\n";
						$content.= "			},";
						$content .= "\r\n";
						$content.= "			{..}";
						if ($v1[0]=='arrays') {
							$content.= "\r\n";
							$content.= "		],";
						}
					}
					else $content.= '"'.(@$v1[4]?$v1[4]:$v1[0]).'",';
				}
				$content.= "\r\n";
				if ($v[0]=='array') $content.= '	},';
				else {
					$content .= "		},";
					$content.= "\r\n";
					$content .= "		..";
					$content.= "\r\n";
					$content.= "	],";
				}
			}
			else {
				$content.= '"'.$v[0].'",';
			}
		}
		$content.= "\r\n";
		$content.= '}';
		$content.= '</pre>';
	}
	return $content;
}
