<?php

include_once (ROOT_DIR.'_api/documentation/pages/users_id_put.php');

$url = 'users';

$method = 'post';

unset($request['img_del']);

$description = 'Creating a new user';
