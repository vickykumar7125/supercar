<?php

$url = 'brands/{id}';

$method = 'put';

$request = array(
	//'id'=>array('int',null,true),
	'name'=>array('string',null,true),
	'rank'=>array('int',null),
	'display'=>array('int',null),
	'img_add'=>array('string',null),
	'img_del'=>array('int',null),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,201'),
	'error_text'=>array('string','error text'),
	'brand'=>array('array','brand data',array(
		'id'=>array('int'),
		'name'=>array('string'),
		'rank'=>array('int'),
		'display'=>array('int'),
		'img'=>array('string'),
	)),
);

$description = 'Brand editing';
