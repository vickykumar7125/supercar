<?php

$url = 'cars/{id}';

$method = 'put';

$request = array(
	'brand'=>array('int',null,true),
	'model'=>array('int',null,true),
	'color'=>array('int',null,true),
	'imgs_add'=>array('array',null),
	'imgs_del'=>array('string',null),
	'docs_add'=>array('array',null),
	'docs_del'=>array('string',null),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,311'),
	'error_text'=>array('string','error text'),
	'car'=>array('array','car data',array(
		'id'=>array('int'),
		'brand'=>array('int'),
		'model'=>array('int',),
		'color'=>array('int'),
		'imgs'=>array('array'),
		'docs'=>array('array'),
	)),
);

$description = 'Car editing';
