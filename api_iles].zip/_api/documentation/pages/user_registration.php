<?php

$token = false;

$url = 'user_registration';

$method = 'post';

$request = array(
	'name'  => array('string','name',true),
	'email' => array('string',null,true),
	'phone' => array('string',null),
	'brand' => array('int',null),
	'model' => array('int',null),
	//'password'  => array('string','password',true),
	//'hash'  => array('string','	md5({email}.md5({password}))',true),
	'uid'   => array('string','device ID for push notification',false),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,31,111,112'),
	'error_text'=>array('str','error text'),
	'user'=>array('array','user data',array(
		'id' => array('int'),
		'created' => array('string'),
		'updated' => array('string'),
		'expiry' => array('string'),
		'email' => array('string'),
		'phone' => array('string'),
		'name' => array('string'),
		'status' => array('int'),
		'tiers'=>array('string'),

	)),
	'token'=> array('string','Device ID for push notification',false),
);

$description = 'Registration';
