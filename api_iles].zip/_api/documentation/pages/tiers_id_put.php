<?php

$url = 'tiers/{id}';

$method = 'put';

$request = array(
	//'id'=>array('int',null,true),
	'name'=>array('string',null,true),
	'rank'=>array('int',null),
	'display'=>array('int',null),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,131'),
	'error_text'=>array('string','error text'),
	'tier'=>array('array','tier data',array(
		'id'=>array('int'),
		'name'=>array('string'),
		'rank'=>array('int'),
		'display'=>array('int'),
	)),
);

$description = 'Tier editing';
