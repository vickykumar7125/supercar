<?php

include_once (ROOT_DIR.'_api/documentation/pages/tiers_id_put.php');

$url = 'tiers';

$method = 'post';

$description = 'Creating a new tier';
