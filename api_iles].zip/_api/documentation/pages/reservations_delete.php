<?php

$url = 'reservations';

$method = 'delete';

$request = array(
	'event'=>array('int',null,true),
	'user'=>array('int',null,true),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12'),
	'error_text'=>array('string','error text'),
);

$description = 'Reservation delete';
