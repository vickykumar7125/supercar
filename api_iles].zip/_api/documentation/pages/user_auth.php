<?php

$token = false;

$url = 'user_auth';

$method = 'post';

$request = array(
	'email'     => array('string','email',true),
	'password'  => array('string','password OR code (temporary password)',true),
	//'hash'  => array('string','	md5({email}.md5({password}))',true),
	'uid'   => array('string','device ID for push notification',false),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,101,102'),
	'error_text'=>array('str','error text'),
	'user'=>array('array','user data',array(
		'id' => array('int'),
		'email' => array('string'),
		'phone' => array('string'),
		'name' => array('string'),
		'status' => array('int'),
		'tiers'=>array('string'),
	)),
	'token'=> array('string','authorization token',false),
);

$description = 'Login';
