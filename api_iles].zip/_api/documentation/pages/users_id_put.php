<?php

$url = 'users/{id}';

$method = 'put';

$request = array(
	//'id'=>array('int',null,true),
	'name'  => array('string','name',true),
	'email' => array('string',null,true),
	'phone' => array('string',null),
	'password'=> array('string','new password'),
	'img_add'=>array('string',null),
	'img_del'=>array('int',null),
	'tiers'=>array('string','tiers id separated by commas (1,2,3) **ONLY FOR ADMIN**',true),
	'status' => array('string','user status **ONLY FOR ADMIN**',true),
	'expiry' => array('string','expiry date **ONLY FOR ADMIN**'),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,111,114,121'),
	'error_text'=>array('string','error text'),
	'user'=>array('array','user data',array(
		'id' => array('int'),
		'created' => array('string'),
		'updated' => array('string'),
		'expiry' => array('string'),
		'email' => array('string'),
		'phone' => array('string'),
		'name' => array('string'),
		'status' => array('int'),
		'tiers'=>array('string'),
		'img'=>array('string'),
		'docs'=>array('array'),
		'licenses'=>array('array'),
	)),
	'token'=> array('string','authorization token',false),
);

$description = 'User editing';
