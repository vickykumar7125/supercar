<?php

$url = 'events/{id}';

$method = 'delete';

$request = array(
	//'id'=>array('string',null,true),
	//'token'=>'token'
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,401,402'),
	'error_text'=>array('string','error text'),
);

$description = 'Event delete';
