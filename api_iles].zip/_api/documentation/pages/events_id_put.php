<?php

$url = 'events/{id}';

$method = 'put';

$request = array(
	//'id'=>array('int',null,true),
	'name'=>array('string',null,true),
	'text'=>array('string',null,true),
	'tiers'=>array('string','tiers id separated by commas (1,2,3)',true),
	'partners'=>array('string','partners id separated by commas (1,2,3)',true),
	'date'=>array('string',null,true),
	'start'=>array('string',null,true),
	'end'=>array('string',null,true),
	'limit_cars'=>array('int','cars limit'),
	'limit_guests'=>array('int','guests limits'),
	'fee'=>array('int'),
	'location'=>array('string'),
	'display'=>array('int',null),
	'img_add'=>array('string',null),
	'img_del'=>array('int',null),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,301'),
	'error_text'=>array('string','error text'),
	'event'=>array('array','event data',array(
		'id'=>array('int'),
		'created' => array('string'),
		'updated' => array('string'),
		'name'=>array('string'),
		'text'=>array('string'),
		'date'=>array('string'),
		'start' => array('string'),
		'end' => array('string'),
		'tiers'=>array('string','tiers id separated by commas (1,2,3)'),
		'partners'=>array('string','partners id separated by commas (1,2,3)'),
		'display'=>array('int'),
		'img'=>array('string'),
	)),
);

$description = 'Event editing';
