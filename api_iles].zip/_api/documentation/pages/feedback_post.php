<?php

$token = true;

$url = 'feedback';

$method = 'post';

$request = array(
	'subject'=>array('string',null,true),
	'text'=>array('string',null,true),
	//'token'=>'token'
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11'),
	'error_text'=>array('str','error text'),
);

$description = 'Feedback';
