<?php

$url = 'promotions/{id}';

$method = 'put';

$request = array(
	//'id'=>array('int',null,true),
	'name'=>array('string',null,true),
	'partner'=>array('int',null,true),
	'display'=>array('int',null),
	'text'=>array('string',null,true),
	'terms'=>array('string',null,true),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,411'),
	'error_text'=>array('string','error text'),
	'promotion'=>array('array','promo data',array(
		'id'=>array('int'),
		'name'=>array('string'),
		'partner'=>array('int'),
		'code'=>array('int'),
		'redeemed'=>array('int'),
		'display'=>array('int'),
		'img'=>array('string'),
		'text'=>array('string'),
		'terms'=>array('string'),
	)),
);

$description = 'Promotion editing';
