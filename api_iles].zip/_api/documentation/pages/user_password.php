<?php

$url = 'user_password';

$method = 'post';

$request = array(
	'password'     => array('string','password',true),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11'),
	'error_text'=>array('str','error text'),
	'token'=> array('string','authorization token',false),
);

$description = 'Change password';
