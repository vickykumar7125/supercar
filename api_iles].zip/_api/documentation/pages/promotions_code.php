<?php

$url = 'promotions_code';

$method = 'post';

$request = array(
	//'id'=>array('int',null,true),
	'promotion'=>array('int',null,true),
	'code'=>array('int',null,true),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,411,413'),
	'error_text'=>array('string','error text'),
	'promotion'=>array('array','promo data',array(
		'id'=>array('int'),
		'name'=>array('string'),
		'partner'=>array('int'),
		'code'=>array('int'),
		'redeemed'=>array('int'),
		'display'=>array('int'),
		'img'=>array('string'),
		'text'=>array('string'),
		'terms'=>array('string'),
	)),
);

$description = 'Promotion code';
