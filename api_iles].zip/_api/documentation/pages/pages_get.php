<?php

$token = false;

$url = 'pages';

$method = 'get';

$request = array(
	'limit'=>array('int','item per page (20 default)'),
	'n'=>array('int','pagination page number (1 default)'),
	'url'=>array('string')
	//'token'=>'token'
);

$answer = array(
	'error'=>array('int','errors ID','0,11,12'),
	'error_text'=>array('str','error text'),
	'pages'=>array('array','events data',array(
		'list'=>array('arrays','list of events',array(
			'id' => array('int'),
			'created' => array('string'),
			'updated' => array('string'),
			'display' => array('int'),
			'name' => array('string'),
			'text' => array('string'),
			'url' => array('string'),
			'description' => array('string'),
		)),
		'num_rows'=>array('int','total number of rows'),
		'limit' => $request['limit'],
		'n' => $request['n'],

	)),
);

$description = 'List of pages';
