<?php

include_once (ROOT_DIR.'_api/documentation/pages/cars_id_put.php');

$url = 'cars';

$method = 'post';

unset($request['imgs_del']);
unset($request['docs_del']);

$description = 'Creating a new car';
