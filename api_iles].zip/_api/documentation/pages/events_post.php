<?php

include_once (ROOT_DIR.'_api/documentation/pages/events_id_put.php');

$url = 'events';

$method = 'post';

unset($request['img_del']);

$description = 'Creating a new event';
