<?php

include_once (ROOT_DIR.'_api/documentation/pages/past_events_id_put.php');

$url = 'past_events';

$method = 'post';

unset($request['imgs_del']);

$description = 'Creating a past event';
