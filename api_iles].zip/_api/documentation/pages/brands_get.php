<?php

$token = false;

$url = 'brands';

$method = 'get';

$request = array(
	'limit'=>array('int','item per page (20 default)'),
	'n'=>array('int','pagination page number (1 default)'),
	//'token'=>'token'
);

$answer = array(
	'error'=>array('int','errors ID','0,11,12'),
	'error_text'=>array('str','error text'),
	'brands'=>array('array','brands data',array(
		'list'=>array('arrays','list brands',array(
			'id' => array('int'),
			'created' => array('string'),
			'updated' => array('string'),
			'rank' => array('int'),
			'display' => array('int'),
			'name' => array('string'),
			'img' => array('string'),
		)),
		'num_rows'=>array('int','total number of rows'),
		'limit' => $request['limit'],
		'n' => $request['n'],

	)),
);

$description = 'List of brands';
