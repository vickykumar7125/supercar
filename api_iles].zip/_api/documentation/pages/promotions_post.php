<?php

include_once (ROOT_DIR.'_api/documentation/pages/promotions_id_put.php');

$url = 'promotions';

$method = 'post';

$description = 'Creating a new promotion';
