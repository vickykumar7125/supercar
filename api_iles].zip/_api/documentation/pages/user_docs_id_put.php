<?php

include_once(ROOT_DIR.'_api/documentation/pages/users_id_put.php');

$url = 'user_docs/{id}';

$method = 'put';

$request = array(
	'docs_add'=>array('array',null),
	'docs_del'=>array('string',null),
	'licenses_add'=>array('array',null),
	'licenses_del'=>array('string',null),
);

$description = 'User docs editing';
