<?php

$url = 'events';

$method = 'get';

$request = array(
	'limit'=>array('int','item per page (20 default)'),
	'n'=>array('int','pagination page number (1 default)'),
	'id'=>array('int','event id'),
	'type'=>array('int','1 - upcoming, 2 - closed')
	//'token'=>'token'
);

$answer = array(
	'error'=>array('int','errors ID','0,11,12'),
	'error_text'=>array('str','error text'),
	'events'=>array('array','events data',array(
		'list'=>array('arrays','list of events',array(
			'id' => array('int'),
			'created' => array('string'),
			'updated' => array('string'),
			'date' => array('string'),
			'start' => array('string'),
			'end' => array('string'),
			'display' => array('int'),
			'name' => array('string'),
			'text' => array('string'),
			'img' => array('string'),
			'limit_cars'=> array('int'),
			'limit_quests'=> array('int'),
			'fee'=> array('int'),
			'location'=> array('str'),
			'reservation' => array('int','reservation id'),
			'status'=> array('str'),
			'users'=>array('arrays','list of users',array(
				'id' => array('int'),
				'name' => array('string'),
				'img'=> array('string'),
				'brand_name'=>array('string'),
				'model_name'=>array('string'),
				'guests'=>array('int'),
			)),
			'brands'=>array('arrays','list of brands',array(
				'id' => array('int'),
				'name' => array('string'),
				'img'=> array('string'),
			)),
			'partners'=>array('arrays','list of partenrs',array(
				'id' => array('int'),
				'name' => array('string'),
				'img'=> array('string'),
			)),
		)),
		'num_rows'=>array('int','total number of rows'),
		'limit' => $request['limit'],
		'n' => $request['n'],

	)),
);

$description = 'List of events';
