<?php

$url = 'promotions';

$method = 'get';

$request = array(
	'limit'=>array('int','item per page (20 default)'),
	'n'=>array('int','pagination page number (1 default)'),
	'type'=>array('int','1 - active, 2 - suspended')
	//'token'=>'token'
);

$answer = array(
	'error'=>array('int','errors ID','0,11,12'),
	'error_text'=>array('str','error text'),
	'promotions'=>array('array','promotions data',array(
		'list'=>array('arrays','list of promotions',array(
			'id' => array('int'),
			'created' => array('string'),
			'updated' => array('string'),
			'name' => array('string'),
			'display' => array('int'),
			'brand' => array('int'),
			'code' => array('int'),
			'redeemed' => array('int'),
			'text' => array('string'),
			'terms' => array('string'),
			'partner' => array('int'),
			'partner_name' => array('string'),
			'partner_phone' => array('string'),
			'partner_location' => array('string'),
			'partner_img' => array('string'),
		)),
		'num_rows'=>array('int','total number of rows'),
		'limit' => $request['limit'],
		'n' => $request['n'],

	)),
);

$description = 'List of promotions';
