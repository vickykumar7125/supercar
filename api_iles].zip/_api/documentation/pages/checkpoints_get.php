<?php

$url = 'checkpoints';

$method = 'get';

$request = array(
	'limit'=>array('int','item per page (20 default)'),
	'n'=>array('int','pagination page number (1 default)'),
	'event'=>array('int')
	//'token'=>'token'
);

$answer = array(
	'error'=>array('int','errors ID','0,11,12'),
	'error_text'=>array('str','error text'),
	'checkpoints'=>array('array','checkpoints data',array(
		'list'=>array('arrays','list of checkpoints',array(
			'id' => array('int'),
			'created' => array('string'),
			'updated' => array('string'),
			'name' => array('string'),
			'lat' => array('string'),
			'lng' => array('string'),
			'hours' => array('string'),
			'minutes' => array('string'),
			'event' => array('int'),
			'checked' => array('int','checked id'),
		)),
		'num_rows'=>array('int','total number of rows'),
		'limit' => $request['limit'],
		'n' => $request['n'],

	)),
);

$description = 'List of checkpoints';
