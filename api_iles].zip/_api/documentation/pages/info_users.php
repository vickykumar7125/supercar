<?php

$description = 'User statuses';

$content = '<table class="table">';
foreach ($config['user_statuses'] as $k=>$v) {
	$content.= '<tr>';
	$content.= '<td>' . $k . '</td>';
	$content.= '<td>' . $v . '</td>';
	$content.= '<td>' . $config['user_description_statuses'][$k] . '</td>';
	$content.= '</tr>';
}
$content.= '</table>';
