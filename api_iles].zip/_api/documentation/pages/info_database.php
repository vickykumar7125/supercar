<?php

$description = 'Database';


$database = array();


function func ($data,$str,$i=0) {
	$count	= strpos($data,$str);
	return substr($data,0,$count+$i);
}

$query = "SHOW TABLES";
if ($tables = mysql_select($query,'rows')) {
	$i = 0;
	foreach ($tables as $table) {
		$tbl = array_shift($table);
		if (!in_array($tbl,array('languages','logs','user_fields','user_types','user_socials'))) {
			$query = "SHOW CREATE TABLE `" . $tbl . "`";
			$q = mysql_select($query, 'row');
			$array = explode("\n", $q['Create Table']);
			$comment = end($array);
			$comment = stristr($comment, "COMMENT");
			$comment = substr($comment, 9);
			$comment = substr($comment, 0, -1);
			$database[$tbl] = array(
				'table_comment'=>$comment,
			);
			$i = 0;
			foreach ($array as $k => $v) {
				$v = trim($v);
				if ($v[0] == '`') {
					$i++;
					$data = stristr($v, "`");
					$data = substr($data, 1);
					$name = func($data, '`', 0);
					$data = stristr($data, " ");
					$data = substr($data, 1);
					$type = func($data, ' ', 0);
					$data = stristr($data, 'COMMENT');
					$data = substr($data, 9);
					$comment = func($data, "'", 0);
					$database[$tbl]['columns'][$i]['name']= $name;
					$database[$tbl]['columns'][$i]['type'] = $type;
					$database[$tbl]['columns'][$i]['comment'] = $comment . '</td>';

				}
			}
		}
	}
}

$content = '';
$i = 0;
foreach ($database as $k=>$table) {
	$i++;
	if (fmod($i,2)==1) $content.= '<div class="clearfix"></div>';
	$content.= '<div class="col-md-6">';
	$content.= '<h3>'.$k.'</h3>';
	$content.= '<table class="table">';
	$content.= '<tr style="color:#999">';
	$content.= '<td>column</td>';
	$content.= '<td>type</td>';
	$content.= '<td>description</td>';
	$content.= '</tr>';
	foreach ($table['columns'] as $k=>$v) {
		$content.= '<tr>';
		$content.= '<td>' . $v['name'] . '</td>';
		$content.= '<td>' . $v['type'] . '</td>';
		$content.= '<td>' . $v['comment'] . '</td>';
		$content.= '</tr>';
	}
	$content.= '</table>';
	$content.= '</div>';
}



