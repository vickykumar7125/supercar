<?php

$url = 'past_events/{id}';

$method = 'put';

$request = array(
	//'id'=>array('int',null,true),
	'name'=>array('string',null,true),
	'text'=>array('string',null,true),
	'date'=>array('string',null,true),
	'participants' => array('int',null,true),
	'location' => array('string',null,true),
	'display'=>array('int',null),
	'imgs_add'=>array('array',null),
	'imgs_del'=>array('string',null),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,301'),
	'error_text'=>array('string','error text'),
	'past_event'=>array('array','past event data',array(
		'id' => array('int'),
		'created' => array('string'),
		'updated' => array('string'),
		'date' => array('string'),
		'display' => array('int'),
		'participants' => array('int'),
		'location' => array('string'),
		'name' => array('string'),
		'text' => array('string'),
		'imgs' => array('arrays','list of images',array(
			'n'=>array('int'),
			'img'=>array('string')
		))
	)),
);

$description = 'Event editing';
