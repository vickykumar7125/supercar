<?php

$url = 'past_events/{id}';

$method = 'delete';

$request = array(
	//'id'=>array('string',null,true),
	//'token'=>'token'
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,351'),
	'error_text'=>array('string','error text'),
);

$description = 'Past event delete';
