<?php

$description = 'About';

$content = '
We are creating an app for the members and the admin to manage users, events and promotions

<br><br>
Requests address: <kbd>'.$config['http_domain'].'/_api/{key}</kbd>
<br>where {key} is the method of API.
<br>
<br>
Errors:
<table cellpadding="0" cellspacing="0" class="table_api_errors">';

foreach($config['api_errors'] as $k => $v){
	$content.= '
    <tr>
        <td>'.$k.'</td>
        <td>'.$v.'</td>
    </tr>';
}
$content.= '</table>';

