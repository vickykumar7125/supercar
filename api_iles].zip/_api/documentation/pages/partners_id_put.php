<?php

$url = 'partners/{id}';

$method = 'put';

$request = array(
	//'id'=>array('int',null,true),
	'name'=>array('string',null,true),
	'phone'=>array('string',null,true),
	'location'=>array('string',null,true),
	'img_add'=>array('string',null),
	'img_del'=>array('int',null),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,401'),
	'error_text'=>array('string','error text'),
	'partner'=>array('array','partner data',array(
		'id'=>array('int'),
		'name'=>array('string'),
		'phone'=>array('string'),
		'location'=>array('string'),
		'img'=>array('string'),
	)),
);

$description = 'Partner editing';
