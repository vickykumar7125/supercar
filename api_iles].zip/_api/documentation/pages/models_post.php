<?php

include_once (ROOT_DIR.'_api/documentation/pages/models_id_put.php');

$url = 'models';

$method = 'post';

unset($request['img_del']);

$description = 'Creating a new model';
