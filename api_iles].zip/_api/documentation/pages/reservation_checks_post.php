<?php

$url = 'reservation_checks';

$method = 'post';

$request = array(
	//'event'=>array('int'),
	'checkpoint'=>array('int'),
	'lat'=>array('string',false,true),
	'lng'=>array('string',false,true),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,321,322,331,332,333,334'),
	'error_text'=>array('string','error text'),
	'distance'=>array('int','distance in meters'),
	'checks'=>array('arrays','check data',array(
		'id'=>array('int'),
		'created'=>array('string'),
		'updated'=>array('string'),
		'user'=>array('int'),
		'checkpoint'=>array('int'),
		'event'=>array('int'),
		'lat'=>array('string'),
		'lng'=>array('string'),
	)),
);

$description = 'Event checkpoint registration';
