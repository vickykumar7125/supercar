<?php

include_once (ROOT_DIR.'_api/documentation/pages/colors_id_put.php');

$url = 'colors';

$method = 'post';

$description = 'Creating a new color';
