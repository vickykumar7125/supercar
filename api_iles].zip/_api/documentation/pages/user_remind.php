<?php

$token = false;

$url = 'user_remind';

$method = 'post';

$request = array(
	'email'     => array('string','email',true),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,112,115'),
	'error_text'=>array('str','error text'),
);

$description = 'Remind password';
