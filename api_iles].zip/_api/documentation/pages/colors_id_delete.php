<?php

$url = 'colors/{id}';

$method = 'delete';

$request = array(
	//'id'=>array('string',null,true),
	//'token'=>'token'
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,231'),
	'error_text'=>array('string','error text'),
);

$description = 'Color delete';
