<?php

include_once (ROOT_DIR.'_api/documentation/pages/partners_id_put.php');

$url = 'partners';

$method = 'post';

unset($request['img_del']);

$description = 'Creating a new partner';
