<?php

$url = 'checkpoints/{id}';

$method = 'put';

$request = array(
	//'id'=>array('int',null,true),
	'name'=>array('string',null,true),
	'lat'=>array('string',null,true),
	'lng'=>array('string',null,true),
	'hours'=>array('string',null,true),
	'minutes'=>array('string',null,true),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,321'),
	'error_text'=>array('string','error text'),
	'checkpoint'=>array('array','checkpoint data',array(
		'id'=>array('int'),
		'name'=>array('string'),
		'lat'=>array('string'),
		'lng'=>array('string'),
		'hours'=>array('string'),
		'minutes'=>array('string'),
	)),
);

$description = 'Checkpoint editing';
