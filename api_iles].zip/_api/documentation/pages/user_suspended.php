<?php

$token = true;

$url = 'user_suspended';

$method = 'post';

$request = array(
	'id'  => array('string','user id',true),
	'text'  => array('string','text',true),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,121'),
	'error_text'=>array('str','error text'),
);

$description = 'User suspended';
