<?php

$url = 'reservations';

$method = 'get';

$request = array(
	'limit'=>array('int','item per page (20 default)'),
	'n'=>array('int','pagination page number (1 default)'),
	'event'=>array('int','event id')
);

$answer = array(
	'error'=>array('int','errors ID','0,11,12'),
	'error_text'=>array('str','error text'),
	'reservations'=>array('array','reservations data',array(
		'list'=>array('arrays','list of reservations',array(
			'id' => array('int'),
			'created' => array('string'),
			'updated' => array('string'),
			'event' => array('int'),
			'user' => array('int'),
			'car' => array('int'),
			'tiers' => array('string'),
			//'checks' => array('int','check ins'),
		)),
		'num_rows'=>array('int','total number of rows'),
		'limit' => $request['limit'],
		'n' => $request['n'],

	)),
);

$description = 'List of reservations';
