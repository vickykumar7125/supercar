<?php

$url = 'models/{id}';

$method = 'put';

$request = array(
	//'id'=>array('int',null,true),
	'name'=>array('string',null,true),
	'brand'=>array('int',null,true),
	'rank'=>array('int',null),
	'display'=>array('int',null),
	'img_add'=>array('string',null),
	'img_del'=>array('int',null),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,221'),
	'error_text'=>array('string','error text'),
	'model'=>array('array','model data',array(
		'id'=>array('int'),
		'name'=>array('string'),
		'rank'=>array('int'),
		'display'=>array('int'),
		'img'=>array('string'),
	)),
);

$description = 'Brand editing';
