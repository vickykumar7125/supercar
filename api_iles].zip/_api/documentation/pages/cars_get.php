<?php

$url = 'cars';

$method = 'get';

$request = array(
	'limit'=>array('int','item per page (20 default)'),
	'n'=>array('int','pagination page number (1 default)'),
	'brand'=>array('int'),
	'model'=>array('int'),
	'user'=>array('int','user id **ONLY FOR ADMIN**'),
	//'token'=>'token'
);

$answer = array(
	'error'=>array('int','errors ID','0,11,12'),
	'error_text'=>array('str','error text'),
	'cars'=>array('array','cars data',array(
		'list'=>array('arrays','list of events',array(
			'id' => array('int'),
			'created' => array('string'),
			'updated' => array('string'),
			'user' => array('int'),
			'brand' => array('int'),
			'brand_name' => array('string'),
			'brand_img' => array('string'),
			'model' => array('int'),
			'model_name' => array('string'),
			'model_img' => array('string'),
			'color' => array('int'),
			'color_name' => array('string'),
			'imgs' => array('arrays','list of images',array(
				'n'=>array('int'),
				'img'=>array('string')
			))
		)),
		'num_rows'=>array('int','total number of rows'),
		'limit' => $request['limit'],
		'n' => $request['n'],

	)),
);

$description = 'List of ecars';
