<?php

include_once (ROOT_DIR.'_api/documentation/pages/checkpoints_id_put.php');

$url = 'checkpoints';

$method = 'post';

$request['event'] = array('int',null,true);

$description = 'Creating a new checkpoint';
