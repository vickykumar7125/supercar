<?php

$url = 'user_uid';

$method = 'post';

$request = array(
	'uid'   => array('string','device ID for push notification',true),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12'),
	'error_text'=>array('str','error text'),
);

$description = 'Change uid';
