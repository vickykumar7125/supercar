<?php

$token = false;

$url = 'past_events';

$method = 'get';

$request = array(
	'limit'=>array('int','item per page (20 default)'),
	'n'=>array('int','pagination page number (1 default)'),
	//'type'=>array('int','1 - upcoming, 2 - closed')
	//'token'=>'token'
);

$answer = array(
	'error'=>array('int','errors ID','0,11,12'),
	'error_text'=>array('str','error text'),
	'past_events'=>array('array','past events data',array(
		'list'=>array('arrays','list of past events',array(
			'id' => array('int'),
			'created' => array('string'),
			'updated' => array('string'),
			'date' => array('string'),
			'display' => array('int'),
			'participants' => array('int'),
			'location' => array('string'),
			'name' => array('string'),
			'text' => array('string'),
			'imgs' => array('arrays','list of images',array(
				'n'=>array('int'),
				'img'=>array('string')
			))
		)),
		'num_rows'=>array('int','total number of rows'),
		'limit' => $request['limit'],
		'n' => $request['n'],

	)),
);

$description = 'List of past events';
