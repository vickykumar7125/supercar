<?php

$url = 'reservations';

$method = 'post';

$request = array(
	//'id'=>array('int',null,true),
	//'user'=>array('int',null,true),
	'car'=>array('int',null,true),
	'event'=>array('int',null,true),
	'guests'=>array('int'),
);

$answer = array(
	'error'=>array('int','errors ID','0,1,11,12,301,302,311,312,313,314'),
	'error_text'=>array('string','error text'),
	'reservation'=>array('array','reservation data',array(
		'id'=>array('int'),
		'user'=>array('int'),
		'car'=>array('int'),
		'event'=>array('int'),
		'guests'=>array('int'),
		//'checks'=>array('int'),
	)),
);

$description = 'Event registration';
