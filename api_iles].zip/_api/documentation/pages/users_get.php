<?php

$url = 'users';

$method = 'get';

$request = array(
	'id'=>array('int','user id'),
	'limit'=>array('int','item per page (20 default)'),
	'n'=>array('int','pagination page number (1 default)'),
	'status'=>array('int'),
	'tier'=>array('int')
	//'token'=>'token'
);

$answer = array(
	'error'=>array('int','errors ID','0,11,12'),
	'error_text'=>array('str','error text'),
	'users'=>array('array','events data',array(
		'list'=>array('arrays','list of events',array(
			'id' => array('int'),
			'id2' => array('int'),
			'created' => array('string'),
			'updated' => array('string'),
			'expiry' => array('string'),
			'email' => array('string'),
			'phone' => array('string'),
			'name' => array('string'),
			'status' => array('int'),
			'tiers'=>array('string'),
			'img' => array('string'),
			'imgs'=>array('array'),
			'docs'=>array('array'),
		)),
		'num_rows'=>array('int','total number of rows'),
		'limit' => $request['limit'],
		'n' => $request['n'],

	)),
);

$description = 'List of users';
