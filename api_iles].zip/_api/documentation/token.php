<?php
if($_SERVER['REMOTE_ADDR']=='127.0.0.1' AND $_SERVER['SERVER_ADDR']=='127.0.0.1'){
    $token = 'faec4fa711a15594d6102f99c4b868';
}
else{
    $token = '';
}
?>