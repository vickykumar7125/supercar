/**
 * Created by home on 27.02.2018.
 */
$(document).ready(function(){
//    $('.datepicker').datepicker({dateFormat:"yy-mm-dd"});


/*

    if ($.isFunction($.fn.daterangepicker)) {
        alert(1)
    }
    else{
        alert(2)
    }
/**/
/*
    $('.datepicker').daterangepicker({
            singleDatePicker: true,
            showDropdowns: true,

            locale: {
                format: 'YYYY-MM-DD',
                "separator": " - ",
                "applyLabel": "Выбрать",
                "cancelLabel": "Отмена",
                "fromLabel": "От",
                "toLabel": "До",
                "customRangeLabel": "Custom",
                "weekLabel": "W",
                "daysOfWeek": [
                    "Вс",
                    "Пн",
                    "Вт",
                    "Ср",
                    "Чт",
                    "Пт",
                    "Сб"
                ],
                "monthNames": [
                    "Январь",
                    "Февраль",
                    "Март",
                    "Апрель",
                    "Май",
                    "Июнь",
                    "Июль",
                    "Август",
                    "Сентябрь",
                    "Октябрь",
                    "Ноябрь",
                    "Декабрь"
                ],
                "firstDay": 1
            }

        }
    );
*/
    $('.show_form').click(function(){
        $(this).hide().next().show();
        return false;
    });
    $('form').on('submit', function(){
        var form = $(this),
        	result = $(this).find('pre'),
			formData = new FormData($(this).get(0)),
			token = $(this).find('.token').val(),
			type = $(form).attr('method'),
			queryString = new URLSearchParams(formData).toString(),
			url = $(form).attr('action');
		$.ajax({
            url: url,
            type: type,
            headers: {
                'token':token
            },
            dataType: 'json',
			contentType: false,
			processData: false,
			data: type=='GET' ? queryString : formData,
            cache: false,
            beforeSend: function(){
                $(result).html('Waiting...');
                $(form).find('button[type=submit]').addClass('disabled');
            },
            success: function(json, textStatus){
				var content = this.type + ': ' + url+ '<br>';
				if (token) {
					content+= 'HTTP_TOKEN: '+token+ '<br>';
                }
				    content+= '<br>';

				    content+= 'REQUEST:'+ '<br>';
					var object = {};
					formData.forEach(function(value, key){
						object[key] = value;
					});
                    content+= JSON.stringify(object, null, 2)  ;

                    content+= '<br><br>';

				    content+= 'RESPONSE:'+ '<br>';
					content+= JSON.stringify(json, null, 2)  ;
                $(result).html(content);
            },
            error: function(XMLHttpRequest, textStatus, errorThrown){
				var content = this.type + ': ' + this.url+ '<br><br>';
				    //content+= XMLHttpRequest.status +'<br><br>';
                 content+= $('<p>').addClass('text-danger').text(errorThrown);
                $(result).html(content);
            },
            complete: function(XMLHttpRequest, textStatus){
                setTimeout(function(){
                    $(form).find('button[type=submit]').removeClass('disabled');
                },2000);
            }
        });
        return false;
    });
});