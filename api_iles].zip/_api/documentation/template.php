<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<title>API <?=$config['domain']?></title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="/_api/documentation/templates/css/bootstrap.min.css">
	<link rel="stylesheet" href="/_api/documentation/templates/css/bootstrap-theme.min.css">
	<link href="/_api/documentation/templates/css/api.css?2" rel="stylesheet" type="text/css" />

	<?php /*
	<script type="text/javascript" src="/_api/documentation/templates/js/jquery-1.11.3.min.js"></script>
 */?>
	<script
			src="https://code.jquery.com/jquery-1.12.4.min.js"
			integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ="
			crossorigin="anonymous"></script>

	<script type="text/javascript" src="/_api/documentation/templates/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/_api/documentation/templates/js/moment.min.js"></script>
	<?php /*
	<script type="text/javascript" src="/templates/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
	<link href="/templates/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css" />
	*/?>
	<script type="text/javascript" src="/_api/documentation/templates/js/api.js?12"></script>

</head>

<body>


<div id="header">
	<div class="container">
		<div class="row">
			<div class="col-sm-2 container"><?=$config['domain']?></div>
			<div class="col-sm-10">
				Technical documentation
			</div>
		</div>
	</div>
</div>

<div class="container">

	<div class="row">

		<div class="col-sm-2 container" >
			<div id="menu">
				<?php
				//dd($pages);
				foreach ($pages as $key=>$val) {
					?>
				<div><?=$key?></div>
				<ul class="row nav nav-pills nav-stacked">
					<?php
					foreach ($val as $k=>$v) {
						if ($v=='-') {
							?>
							<li style="height:1px; background: #337ab7"></li>
						<?php
						}
						else {
							?>
							<li <?= $k == $page ? 'class="active"' : '' ?>><a href="?page=<?= $k ?>"><?= $v ?></a></li>
							<?php
						}
					}
					?>
				</ul>
					<?php
				}
				?>
			</div>
		</div>

		<div class="col-sm-10" id="content">

			<?php
			//dd($page);
			if (file_exists('pages/'.$page.'.php')) {
				include('pages/' . $page . '.php');
				?>
				<h3><?=$description?></h3>
				<?php
			}
			else echo '404';
			if (isset($content)) echo $content;
			if (isset($request)) echo table ('request',$request);
			if (isset($answer)) echo table ('answer',$answer);
			?>
		</div>

	</div>
</div>


<div id="footer">
	<div class="container">
		<?=date('Y')?> © <?=i18n("common|name_title")?>
	</div>
</div>

</body>

<script>
	

</script>

</html>