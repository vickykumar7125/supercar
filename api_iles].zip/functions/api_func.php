<?php

/**
 * @param array $a_data
 */
function parse_http_request(array &$a_data) {
	// read incoming data
	$input = file_get_contents('php://input');
	$substr = substr($input, 0, 6);
	if ($substr=='------') {
		//echo $input;

		// grab multipart boundary from content type header
		preg_match('/boundary=(.*)$/', $_SERVER['CONTENT_TYPE'], $matches);
		$boundary = $matches[1];

		// split content by boundary and get rid of last -- element
		$a_blocks = preg_split("/-+$boundary/", $input);
		array_pop($a_blocks);

		// loop data blocks
		foreach ($a_blocks as $id => $block) {
			if (empty($block))
				continue;

			// you'll have to var_dump $block to understand this and maybe replace \n or \r with a visibile char

			// parse uploaded files
			if (strpos($block, 'application/octet-stream') !== FALSE) {
				// match "name", then everything after "stream" (optional) except for prepending newlines
				preg_match("/name=\"([^\"]*)\".*stream[\n|\r]+([^\n\r].*)?$/s", $block, $matches);

			}
			// parse all other fields
			else {
				// match "name" and optional value in between newline sequences
				preg_match('/name=\"([^\"]*)\"[\n|\r]+([^\n\r].*)?\r$/s', $block, $matches);
				//dd($matches);
			}
			//echo $matches[1].'-';
			//если нет массивов
			if (strripos($matches[1], '[') === false) {
				$a_data[$matches[1]] = $matches[2];
			}
			else {
				$str = $matches[1];
				$str = str_replace(']', '', $str);
				$arr = explode('[', $str);
				$count = count($arr);
				if ($count == 2) {
					if ($arr[1]) $a_data[$arr[0]][$arr[1]] = $matches[2];
					else $a_data[$arr[0]][] = $matches[2];
				}
				if ($count == 3) {
					if ($arr[2]) $a_data[$arr[0]][$arr[1]][$arr[2]] = $matches[2];
					else $a_data[$arr[0]][$arr[1]][] = $matches[2];
				}
				if ($count == 4) {
					if ($arr[3]) $a_data[$arr[0]][$arr[1]][$arr[2]][$arr[3]] = $matches[2];
					else $a_data[$arr[0]][$arr[1]][$arr[2]][] = $matches[2];
				}
			}
		}
	}
	else {
		$a_data = json_decode($input, true);
	}
}

/**
 * @param $table
 * @param $post
 * @param $key
 * @param $images
 * @return mixed
 */
function api_img ($table,$post,$key,$images) {
	$path = ROOT_DIR . 'files/'.$table.'/' . $post['id'] . '/'.$key.'/';
	$update = 0;
	//удаление картинки
	if ($images[$key.'_add'] OR $images[$key.'_del'] AND $post[$key]!='') {
		delete_all($path);
		$post[$key] = '';
		$update++;
	}
	//добавление картинки
	if ($images[$key.'_add']) {
		//тело картинки
		$content = base64_decode($images[$key.'_add']);
		if ($ext = get_mime_type ($content)) {
			//название картинки
			$file_name = md5($content);
			$file_name = substr($file_name, 0, 10);
			$file_name .= '.'.$ext;
			$file = $path . $file_name;
			if (is_dir($path) || mkdir($path, 0755, true)) {
				$fp = fopen($file, 'w');
				fwrite($fp, $content);
				fclose($fp);
				//img_process('resize', $file, '100x100', $path . 'a-' . $file_name);
				img_process('resize', $file, '1500x1500', $file);
				$post[$key] = $file_name;
			}
		}
	}
	if ($update) {
		mysql_fn('update',$table,$post);
	}
	return $post;
}

function api_imgs ($table,$post,$key,$images) {
	//dd($images);
	$path = ROOT_DIR . 'files/'.$table.'/' . $post['id'] . '/'.$key.'/';
	$update = 0;
	$imgs = array();
	if ($post[$key]) {
		$imgs = unserialize($post[$key]);
	}
	//удаление картинки
	if ($images[$key.'_del'] AND $post[$key]!='') {
		$delete = explode(',',$images[$key.'_del']);
		foreach ($delete as $k=>$v) {
			if (isset($imgs[$v])) {
				delete_all($path . $v . '/');
				unset($imgs[$v]);
				$update++;
			}
		}
	}
	//добавление картинки
	if ($images[$key.'_add']) {
		$n = 1;
		if ($imgs) foreach ($imgs as $k=>$v) {
			if ($k>=$n) $n = $k+1;
		}
		//dd($images[$key.'_add']);
		foreach ($images[$key.'_add'] as $k=>$v) {
			//тело картинки
			$content = base64_decode($v);
			if ($ext = get_mime_type($content)) {
				$path_img = $path.$n.'/';
				//название картинки
				$file_name = md5($content);
				$file_name = substr($file_name, 0, 10);
				$file_name .= '.' . $ext;
				$file = $path_img . $file_name;
				if (is_dir($path_img) || mkdir($path_img, 0755, true)) {
					$fp = fopen($file, 'w');
					fwrite($fp, $content);
					fclose($fp);
					//img_process('resize', $file, '100x100', $path_img . 'a-' . $file_name);
					$imgs[$n]['file'] = $file_name;
					$n++;
					$update++;
				}
			}
		}
	}
	if ($update) {
		$post[$key] = $imgs ? serialize($imgs) : '';
		mysql_fn('update',$table,$post);
	}
	return $post;
}

function get_mime_type ($content) {
	$file_info = new finfo(FILEINFO_MIME_TYPE);
	$mime_type = $file_info->buffer($content);
	$array = array(
		'image/jpeg'=>'jpg',
		'image/gif'=>'gif',
		'image/svg+xml'=>'svg',
		'image/png'=>'png'
	);
	if (isset($array[$mime_type])) {
		return $array[$mime_type];
	}
	return false;
}