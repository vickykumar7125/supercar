<?php

function pusher($template,$language=1,$q,$ids=array()) {
	if ($language==false) $language = 1;
	//echo "SELECT * FROM letter_templates WHERE name='".$template."'";
	if ($push_template = mysql_select("SELECT * FROM push_templates WHERE name='".$template."'",'row')) {
		if (isset($q['date'])) {
			$q['_date'] = date2($q['date'],'d month y');
		}
		$data = array(
			'title'=>template($push_template['title'],$q),
			'body'=>template($push_template['body'],$q)
		);
		if ($template=='event_created' OR $template=='event_started') {
			//log_add('test_push.txt',$q);
			if ($q['tiers'] AND $q['name']) {
				$where = mysql_where('find_in_set', 'tiers', $q['tiers']);
				$users = mysql_select("
				SELECT uid FROM users
				WHERE status=1 AND uid!='' " . $where, 'rows');
				//log_add('test_push.txt',$where);
				//log_add('test_push.txt',$users);
				/*log_add('test.txt',"
					SELECT uid FROM users
					WHERE status=1 AND uid!='' ".$where);
				*/
				if ($users) foreach ($users as $usr) {
					$ids[] = $usr['uid'];
				}
				if ($ids == false) return false;
			}
			else return false;
		}
		if ($template=='promotion_created') {
			$users = mysql_select("
				SELECT uid FROM users
				WHERE status=1 AND uid!='' ",'rows');
			//log_add('users.txt',$users);
			if ($users) foreach ($users as $usr) {
				$ids[] = $usr['uid'];
			}
			if ($ids==false) return false;
		}
		//если не указан адресат то админу
		if ($ids==false) {
			$users = mysql_select("SELECT uid FROM users WHERE status=99 AND uid!=''",'rows');
			if ($users) foreach ($users as $usr) {
				$ids[] = $usr['uid'];
			}
		}
		if ($ids) {
			//отправка пуша
			return push($ids, $data);
		}
	}
}



//https://firebase.google.com/docs/cloud-messaging/http-server-ref#downstream-http-messages-json
function push ($ids,$data,$debug=false) {
	global $config;
	$api_key = 'AIzaSyCukwZKHFMPYr0_Alpc-glNWB6UQQ_zNik';
	$api_key = 'AAAA_yAUHMg:APA91bEey_g30IzsIwlr2uJ8PeBw1G7VXnpViewQOsRkxU5sQGmUqQMHbtf7bhHxhKRTdr1RSPdf-k30_fxzDm9dAKL7xIpi6Wt96amwOh6ib8JKbb9r2pNCjjt0WTEhLMALO25dyNKd';
	$sender_id = '1095754849480';
	$url = 'https://fcm.googleapis.com/fcm/send';
	if (is_string($ids)) {
		$ids = array($ids);
	}
	$results = array();
	foreach ($ids as $k=>$v) {
		$fields = array(
			'to' => $v,
			//'gcm_sender_id'=>$sender_id,
			//'registration_ids'=>$ids,
			//'data'=>$data,
			'notification' => $data,
			/*
			'notification' => array(
				'title' =>'title',
				'body' => 'body of message.',
				//'icon' =>'https://scmajlis.ae/img/logo.png',
				//'sound' => 'mySound'
			),*/
			//'priority'=>'high',
			//'time_to_live'=>86400
		);
		$fields['notification']['sound'] = "default";
		if ($debug) {
			echo $api_key;
			echo '<br>REQUEST';
			echo '<pre>';
			print_r($fields);
			echo '</pre>';
		}
		mysql_fn('insert', 'pushes', array(
			'created' => $config['datetime'],
			'data' => serialize($fields)
		));
		if ($config['push_on']) {
			$headers = array(
				'Authorization: key=' . $api_key,
				'Content-Type: application/json'
			);
			// Open connection
			$ch = curl_init();
			// Set the url, number of POST vars, POST data
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			// Disabling SSL Certificate support temporarly
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
			// Execute post
			$result = curl_exec($ch);
			if ($result === FALSE) {
				die('Curl failed: ' . curl_error($ch));
			}
			// Close connection
			curl_close($ch);
			$response = json_decode($result, true);
			//log_add('push.txt',$data);
			if ($debug) {
				echo '<br>RESPONSE';
				echo '<pre>';
				echo $result;
				print_r($response);
				echo '</pre>';
			}
			$results[] = $response;
		}
	}
	return $results;
}